<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('Location: index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Painel Admin</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h1>Painel Admin</h1>
    <nav>
        <ul>
            <li><a href="inserir_produto.php">Inserir Produtos</a></li>
            <li><a href="visualizar_retiradas.php">Visualizar Retiradas</a></li>
            <li><a href="gerenciar_usuarios.php">Gerenciar Usuários</a></li>
            <li><a href="logout.php">Sair</a></li>
        </ul>
    </nav>
</body>
</html>
