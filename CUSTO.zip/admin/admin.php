<?php
include '../conexao.php';
session_start();

if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

// Consultas para o mês atual, mês anterior, vendas de hoje e vendas de ontem
$current_month = date('Y-m'); // Mês atual
$yesterday = date('Y-m-d', strtotime('-1 day')); // Ontem
$today = date('Y-m-d'); // Hoje

// Consultas para as vendas do mês atual, mês anterior, de hoje e de ontem
$query_vendas = "
    SELECT 
        (SELECT SUM(r.quantidade * p.preco_venda) 
         FROM retiradas r 
         JOIN produtos p ON r.produto_id = p.id 
         WHERE DATE_FORMAT(r.data_retirada, '%Y-%m') = :current_month) AS total_venda_mes_atual,
        (SELECT SUM(r.quantidade * p.preco_venda) 
         FROM retiradas r 
         JOIN produtos p ON r.produto_id = p.id 
         WHERE DATE_FORMAT(r.data_retirada, '%Y-%m') = :last_month) AS total_venda_mes_anterior,
        (SELECT SUM(r.quantidade * p.preco_venda) 
         FROM retiradas r 
         JOIN produtos p ON r.produto_id = p.id 
         WHERE DATE(r.data_retirada) = :today) AS total_venda_hoje,
        (SELECT SUM(r.quantidade * p.preco_venda) 
         FROM retiradas r 
         JOIN produtos p ON r.produto_id = p.id 
         WHERE DATE(r.data_retirada) = :yesterday) AS total_venda_ontem
";
$stmt = $conn->prepare($query_vendas);
$stmt->execute([
    ':current_month' => $current_month,
    ':last_month' => date('Y-m', strtotime('-1 month')),
    ':today' => $today,
    ':yesterday' => $yesterday
]);
$totais_vendas = $stmt->fetch(PDO::FETCH_ASSOC);

// Formatação dos valores
$total_venda_mes_atual = isset($totais_vendas['total_venda_mes_atual']) ? number_format($totais_vendas['total_venda_mes_atual'], 2, ',', '.') : '0,00';
$total_venda_mes_anterior = isset($totais_vendas['total_venda_mes_anterior']) ? number_format($totais_vendas['total_venda_mes_anterior'], 2, ',', '.') : '0,00';
$total_venda_hoje = isset($totais_vendas['total_venda_hoje']) ? number_format($totais_vendas['total_venda_hoje'], 2, ',', '.') : '0,00';
$total_venda_ontem = isset($totais_vendas['total_venda_ontem']) ? number_format($totais_vendas['total_venda_ontem'], 2, ',', '.') : '0,00';
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel de Vendas</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #FF7043, #FF9800, #FF5722); /* Gradiente de cores laranja e vermelho */
            background-size: 400% 400%;
            animation: gradient 15s ease infinite;
            margin: 0;
            padding: 0;
            color: white;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        h1 {
            text-align: center;
            margin-top: 20px;
            font-size: 3em;
        }
        .container {
            display: flex;
            justify-content: center;
            padding: 20px;
            flex-wrap: wrap;
            flex-grow: 1; /* Faz o conteúdo crescer para ocupar o máximo de espaço possível */
        }
        .card {
            background: rgba(0, 0, 0, 0.7);
            border-radius: 10px;
            padding: 20px;
            margin: 10px;
            width: 250px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
            text-align: center;
        }
        .card h2 {
            margin-bottom: 15px;
            font-size: 1.5em;
        }
        .card p {
            font-size: 1.2em;
            margin: 5px 0;
        }
        .card .value {
            font-size: 2em;
            font-weight: bold;
        }
        .sidebar {
            position: absolute;
            top: 0;
            left: 0;
            background: #111;
            width: 250px;
            height: 100%;
            padding: 20px;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.5); /* Sombras nos blocos do menu */
        }
        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }
        .sidebar ul li {
            margin: 20px 0;
        }
        .sidebar ul li a {
            text-decoration: none;
            color: white;
            font-size: 1.2em;
            display: block;
            padding: 10px;
            border-radius: 10px; /* Bordas arredondadas */
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.3); /* Sombras nos blocos do menu */
        }

        .sidebar ul li a:hover {
            background-color: #FF5722; /* Cor laranja quando hover */
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.4); /* Aumentando a sombra ao passar o mouse */
        }

        /* Animations */
        @keyframes gradient {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* Responsividade */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
                align-items: center;
            }

            .card {
                width: 90%;
                margin: 15px 0;
            }

            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 20px;
            width: 100%;
            margin-top: auto; /* Faz o rodapé ir para o fundo da página */
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <ul>
            <li><a href="admin.php">HOME</a></li>
            <li><a href="inserir_produto.php">Inserir Produtos</a></li>
            <li><a href="visualizar_retiradas.php">Visualizar Vendas</a></li>
            <li><a href="gerenciar_usuarios.php">Gerenciar Usuários</a></li>
            <li><a href="visualizar_produtos.php">Ver Produtos</a></li>
            <li><a href="https://wa.me/5581987832868">SUPORTE</a></li>
            <li><a href="index.php">Sair</a></li>
        </ul>
    </div>

    <div class="container">
        <div class="card">
            <h2>Vendas Mês Atual</h2>
            <p class="value">R$ <?php echo $total_venda_mes_atual; ?></p>
        </div>
        <div class="card">
            <h2>Vendas Mês Anterior</h2>
            <p class="value">R$ <?php echo $total_venda_mes_anterior; ?></p>
        </div>
        <div class="card">
            <h2>Vendas Hoje</h2>
            <p class="value">R$ <?php echo $total_venda_hoje; ?></p>
        </div>
        <div class="card">
            <h2>Vendas Ontem</h2>
            <p class="value">R$ <?php echo $total_venda_ontem; ?></p>
        </div>
    </div>

    <!-- Rodapé -->
     <br>
    <footer>
        <p>&copy; 2024 Painel Inforcusto Gerenciar. Todos os direitos reservados.</p>
    </footer>

</body>
</html>
