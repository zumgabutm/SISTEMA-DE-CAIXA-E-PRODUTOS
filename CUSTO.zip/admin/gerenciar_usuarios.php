<?php
include '../conexao.php';
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

$usuarios = $conn->query("SELECT * FROM usuarios")->fetchAll(PDO::FETCH_ASSOC);
$message = ''; // Variável para mensagens de feedback

// Adicionar um novo usuário
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_usuario'])) {
    $nome = trim($_POST['nome']);
    $sobrenome = trim($_POST['sobrenome']);
    $email = trim($_POST['email']);
    $senha = trim($_POST['senha']);

    // Validações básicas
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Erro: E-mail inválido!';
    } elseif (strlen($senha) < 6) {
        $message = 'Erro: A senha deve ter pelo menos 6 caracteres!';
    } else {
        // Verificar se o e-mail já está cadastrado
        $stmt = $conn->prepare("SELECT COUNT(*) FROM usuarios WHERE email = ?");
        $stmt->execute([$email]);
        $emailExistente = $stmt->fetchColumn();

        if ($emailExistente > 0) {
            $message = 'Erro: O e-mail já está cadastrado!';
        } else {
            try {
                $stmt = $conn->prepare("INSERT INTO usuarios (nome, sobrenome, email, senha) VALUES (?, ?, ?, ?)");
                $stmt->execute([$nome, $sobrenome, $email, password_hash($senha, PASSWORD_DEFAULT)]);
                $message = 'Usuário adicionado com sucesso!';
            } catch (Exception $e) {
                $message = 'Erro ao adicionar usuário: ' . htmlspecialchars($e->getMessage());
            }
        }
    }
}

// Alterar a senha do usuário
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['alterar_senha'])) {
    $usuario_id = $_POST['usuario_id'];
    $nova_senha = password_hash(trim($_POST['nova_senha']), PASSWORD_DEFAULT);

    try {
        $stmt = $conn->prepare("UPDATE usuarios SET senha = ? WHERE id = ?");
        $stmt->execute([$nova_senha, $usuario_id]);
        $message = 'Senha alterada com sucesso!';
    } catch (Exception $e) {
        $message = 'Erro ao alterar senha: ' . htmlspecialchars($e->getMessage());
    }
}

// Remover usuário
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['remover_usuario'])) {
    $usuario_id = $_POST['usuario_id'];

    try {
        $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
        $stmt->execute([$usuario_id]);
        $message = 'Usuário removido com sucesso!';
    } catch (Exception $e) {
        $message = 'Erro ao remover usuário: ' . htmlspecialchars($e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Gerenciar Usuários</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(270deg, #2c003e, #5a2d91, #6a1b9a, #ab47bc, #4e1b6d, #3f0058, #0a0022);
            background-size: 400% 400%;
            animation: gradientAnimation 15s ease infinite;
            margin: 0;
            padding: 20px;
            color: #ffffff;
        }

        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            25% { background-position: 50% 50%; }
            50% { background-position: 100% 50%; }
            75% { background-position: 50% 50%; }
            100% { background-position: 0% 50%; }
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            margin-bottom: 30px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        input {
            padding: 10px;
            margin: 5px 0;
            width: 300px;
            border: none;
            border-radius: 5px;
            background-color: #444;
            color: #fff;
        }

        button {
            background-color: #6a1b9a;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #4e1b6d;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #444;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        th {
            background: linear-gradient(to right, #6a1b9a, #ab47bc);
            color: white;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        td {
            background-color: #333;
            transition: background-color 0.3s;
        }

        tr:hover td {
            background-color: #444; /* Cor ao passar o mouse */
        }

        .message {
            text-align: center;
            margin: 10px 0;
            color: #00ff00; /* Verde para feedback positivo */
        }

        .error {
            color: #ff0000; /* Vermelho para feedback de erro */
        }
    </style>
</head>
<body>
    <h1>Gerenciar Usuários</h1>
    <div class="message"><?php echo $message; ?></div> <!-- Mensagem de feedback -->
    <form method="POST" action="">
        <input type="text" name="nome" placeholder="Nome" required>
        <input type="text" name="sobrenome" placeholder="Sobrenome" required>
        <input type="email" name="email" placeholder="E-mail" required>
        <input type="password" name="senha" placeholder="Senha" required>
        <button type="submit" name="add_usuario">Adicionar Usuário</button>
    </form>

    <h2>Usuários Cadastrados</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Sobrenome</th>
            <th>E-mail</th>
            <th>Ações</th>
        </tr>
        <?php foreach ($usuarios as $usuario): ?>
        <tr>
            <td><?php echo $usuario['id']; ?></td>
            <td><?php echo $usuario['nome']; ?></td>
            <td><?php echo $usuario['sobrenome']; ?></td>
            <td><?php echo $usuario['email']; ?></td>
            <td>
                <form method="POST" action="" style="display:inline;">
                    <input type="hidden" name="usuario_id" value="<?php echo $usuario['id']; ?>">
                    <input type="password" name="nova_senha" placeholder="Nova Senha" required>
                    <button type="submit" name="alterar_senha">Alterar Senha</button>
                </form>
                <form method="POST" action="" style="display:inline;">
                    <input type="hidden" name="usuario_id" value="<?php echo $usuario['id']; ?>">
                    <button type="submit" name="remover_usuario" onclick="return confirm('Tem certeza que deseja remover este usuário?');">Remover</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
