<?php
include '../conexao.php';
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

// Função para zerar o histórico de devoluções
if (isset($_POST['zerar_historico'])) {
    // Verifica se é o administrador ou se o usuário está tentando zerar seu próprio histórico
    if ($_SESSION['role'] === 'admin' || $_SESSION['usuario_id'] === $_POST['usuario_id']) {
        try {
            // Deletar as devoluções
            $stmt = $conn->prepare("DELETE FROM devolucoes WHERE usuario_id = ?");
            $stmt->execute([$_POST['usuario_id']]);

            // Redireciona após a exclusão
            $_SESSION['sucesso'] = 'Histórico de devoluções apagado com sucesso!';
            header('Location: historico_devolucoes.php');
            exit;
        } catch (PDOException $e) {
            $_SESSION['erro'] = 'Erro ao apagar o histórico: ' . $e->getMessage();
        }
    } else {
        $_SESSION['erro'] = 'Você não tem permissão para apagar o histórico de devoluções de outro usuário.';
    }
}

// Buscar histórico de devoluções
$query_devolucoes = "
    SELECT d.data_devolucao AS data, p.nome AS produto, d.quantidade, d.usuario_id
    FROM devolucoes d
    JOIN produtos p ON d.produto_id = p.id
    ORDER BY d.data_devolucao DESC
";

try {
    $devolucoes = $conn->query($query_devolucoes)->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $_SESSION['erro'] = 'Erro ao buscar histórico de devoluções: ' . $e->getMessage();
    $devolucoes = [];
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Histórico de Devoluções</title>
    <style>
        /* Estilos do painel */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(270deg, #2c003e, #5a2d91, #6a1b9a, #ab47bc, #4e1b6d, #3f0058, #0a0022, #5a2d91);
            background-size: 400% 400%;
            animation: gradientAnimation 15s ease infinite;
            margin: 0;
            padding: 20px;
            color: #ffffff;
        }

        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            25% { background-position: 50% 50%; }
            50% { background-position: 100% 50%; }
            75% { background-position: 50% 50%; }
            100% { background-position: 0% 50%; }
        }

        .container {
            display: flex;
        }

        .sidebar {
            width: 200px;
            background-color: #1a1a1a;
            color: white;
            padding: 20px;
            border-radius: 5px;
            margin-right: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
        }

        .sidebar h2 {
            margin: 0 0 10px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar ul li {
            margin: 10px 0;
        }

        .sidebar ul li a {
            color: white;
            text-decoration: none;
            padding: 8px;
            display: block;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .sidebar ul li a:hover {
            background-color: #4e1b6d;
        }

        .main-content {
            flex: 1;
            background-color: #2a2a2a;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 15px;
            border: 1px solid #444;
            text-align: left;
        }

        th {
            background: linear-gradient(to right, #6a1b9a, #ab47bc);
            color: white;
            font-weight: bold;
            text-transform: uppercase;
        }

        td {
            background-color: #333;
        }

        tr:hover td {
            background-color: #444;
        }

        .button-zerar {
            background-color: #ff4757;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .button-zerar:hover {
            background-color: #ff6b81;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>Painel de Controle</h2>
            <ul>
                <li><a href="inserir_produto.php">Inserir Produtos</a></li>
                <li><a href="visualizar_retiradas.php">Visualizar Retiradas</a></li>
                <li><a href="gerenciar_usuarios.php">Gerenciar Usuários</a></li>
                <li><a href="visualizar_produtos.php">Ver Produtos</a></li>
                <li><a href="historico_devolucoes.php">Histórico de Devoluções</a></li> <!-- Link do histórico -->
                <li><a href="index.php">Sair</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <h1>Histórico de Devoluções</h1>

            <?php if (isset($_SESSION['sucesso'])): ?>
                <div style="color: green;">
                    <p><?php echo $_SESSION['sucesso']; unset($_SESSION['sucesso']); ?></p>
                </div>
            <?php elseif (isset($_SESSION['erro'])): ?>
                <div style="color: red;">
                    <p><?php echo $_SESSION['erro']; unset($_SESSION['erro']); ?></p>
                </div>
            <?php endif; ?>

            <table>
                <tr>
                    <th>Produto</th>
                    <th>Quantidade Devolvida</th>
                    <th>Data da Devolução</th>
                </tr>
                <?php if (!empty($devolucoes)): ?>
                    <?php foreach ($devolucoes as $devolucao): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($devolucao['produto']); ?></td>
                        <td><?php echo htmlspecialchars($devolucao['quantidade']); ?></td>
                        <td><?php echo date('d/m/Y H:i:s', strtotime($devolucao['data'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3">Nenhuma devolução registrada.</td>
                    </tr>
                <?php endif; ?>
            </table>

            <!-- Formulário para zerar histórico -->
            <form method="POST" action="historico_devolucoes.php">
                <input type="hidden" name="usuario_id" value="<?php echo $_SESSION['usuario_id']; ?>">
                <button type="submit" name="zerar_historico" class="button-zerar">Zerar Histórico de Devoluções</button>
            </form>
        </div>
    </div>
</body>
</html>
