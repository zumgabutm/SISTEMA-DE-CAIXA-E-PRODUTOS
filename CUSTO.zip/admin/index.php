<?php
session_start();

// Exemplo de credenciais armazenadas em variáveis (para produção, use um método mais seguro)
$usuario_correto = 'admin';
$senha_correta = 'admin2';
$erro = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = trim($_POST['usuario']);
    $senha = trim($_POST['senha']);

    if ($usuario === $usuario_correto && $senha === $senha_correta) {
        $_SESSION['loggedin'] = true;
        header('Location: admin.php');
        exit;
    } else {
        $erro = "Usuário ou senha incorretos.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Login Admin</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(270deg, #2c003e, #5a2d91, #6a1b9a, #ab47bc, #4e1b6d, #3f0058, #0a0022, #5a2d91);
            background-size: 400% 400%;
            animation: gradientAnimation 15s ease infinite;
            margin: 0;
            padding: 20px;
            color: #ffffff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
        }

        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            25% { background-position: 50% 50%; }
            50% { background-position: 100% 50%; }
            75% { background-position: 50% 50%; }
            100% { background-position: 0% 50%; }
        }

        .form-container {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
            width: 300%;
            max-width: 250px;
            text-align: center;
        }

        h2 {
            font-size: 1.5em; 
            color: #ffeb3b; 
            margin: 0; 
        }

        input {
            width: 80%;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
            background-color: #444;
            color: #fff;
        }

        button {
            background-color: #6a1b9a;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 70%;
        }

        button:hover {
            background-color: #4e1b6d;
        }

        .back-button {
            margin-top: 10px;
            background-color: #ff5722;
            padding: 10px;
            border-radius: 5px;
            display: inline-block;
            text-decoration: none;
            color: white;
        }

        .back-button:hover {
            background-color: #e64a19;
        }

        .error-message {
            color: #ff4d4d; 
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Bem-vindo à Área do Admin</h2>
        <form method="POST" action="">
            <label for="usuario">Usuário:</label>
            <input type="text" name="usuario" id="usuario" placeholder="Usuário" required aria-label="Usuário">
            <label for="senha">Senha:</label>
            <input type="password" name="senha" id="senha" placeholder="Senha" required aria-label="Senha">
            <button type="submit">Entrar</button>
            <?php if (!empty($erro)) echo "<p class='error-message'>$erro</p>"; ?>
        </form>
        <a href="http://rszeus.shop/custo" class="back-button">Voltar para a Área do Cliente</a>
    </div>
</body>
</html>
