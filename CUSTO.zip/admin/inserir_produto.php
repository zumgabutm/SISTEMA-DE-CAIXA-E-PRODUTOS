<?php
include '../conexao.php';
session_start();

if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

// Processar a adição ou reposição de produtos
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'] ?? null;
    $quantidade = $_POST['quantidade'] ?? null;
    $validade = $_POST['validade'] ?? null;
    $preco_compra = $_POST['preco_compra'] ?? null; // Preço de compra
    $preco_venda = $_POST['preco_venda'] ?? null; // Preço de venda
    $produto_id = $_POST['produto_id'] ?? null; // Para edição
    $categoria_id = $_POST['categoria_id'] ?? null; // Para a categoria

    // Validação simples
    if ($quantidade < 1) {
        $erro = "A quantidade deve ser maior que zero.";
    } elseif ($validade && strtotime($validade) < time()) {
        $erro = "A data de validade não pode estar no passado.";
    } elseif (!$categoria_id) {
        $erro = "A categoria é obrigatória.";
    } elseif ($preco_compra <= 0 || $preco_venda <= 0) {
        $erro = "Os preços devem ser maiores que zero.";
    } else {
        try {
            if ($produto_id && isset($_POST['atualizar'])) {
                // Atualizar quantidade, validade, categoria, preços do produto existente
                $stmt = $conn->prepare("UPDATE produtos SET nome = ?, quantidade = quantidade + ?, validade = ?, categoria_id = ?, preco_compra = ?, preco_venda = ? WHERE id = ?");
                $stmt->execute([$nome, $quantidade, $validade, $categoria_id, $preco_compra, $preco_venda, $produto_id]);
                $sucesso = "Produto atualizado com sucesso.";
            } else if ($produto_id && isset($_POST['retirar'])) {
                // Retirar quantidade do produto existente e calcular lucro
                $stmt = $conn->prepare("SELECT preco_compra, preco_venda FROM produtos WHERE id = ?");
                $stmt->execute([$produto_id]);
                $produto = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($produto) {
                    $lucro = ($produto['preco_venda'] - $produto['preco_compra']) * $quantidade;
                    // Atualiza a quantidade no estoque
                    $stmt = $conn->prepare("UPDATE produtos SET quantidade = quantidade - ? WHERE id = ?");
                    $stmt->execute([$quantidade, $produto_id]);
                    $sucesso = "Quantidade retirada com sucesso. Lucro apurado: R$ " . number_format($lucro, 2, ',', '.');
                }
            } else if ($nome) {
                // Verificar se o produto já existe
                $stmt = $conn->prepare("SELECT * FROM produtos WHERE nome = ?");
                $stmt->execute([$nome]);
                $produto = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($produto) {
                    // Se o produto existe, atualizar a quantidade
                    $nova_quantidade = $produto['quantidade'] + $quantidade;
                    $stmt = $conn->prepare("UPDATE produtos SET quantidade = ?, validade = ?, categoria_id = ?, preco_compra = ?, preco_venda = ? WHERE id = ?");
                    $stmt->execute([$nova_quantidade, $validade, $categoria_id, $preco_compra, $preco_venda, $produto['id']]);
                    $sucesso = "Quantidade atualizada com sucesso.";
                } else {
                    // Se o produto não existe, inserir um novo
                    $stmt = $conn->prepare("INSERT INTO produtos (nome, quantidade, validade, categoria_id, preco_compra, preco_venda) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$nome, $quantidade, $validade, $categoria_id, $preco_compra, $preco_venda]);
                    $sucesso = "Produto adicionado com sucesso.";
                }
            }
        } catch (PDOException $e) {
            $erro = "Erro ao processar a solicitação: " . $e->getMessage();
        }
    }
}

// Buscar produtos existentes
$produtos = $conn->query("SELECT p.*, c.nome AS categoria FROM produtos p JOIN categorias c ON p.categoria_id = c.id")->fetchAll(PDO::FETCH_ASSOC);

// Buscar todas as categorias disponíveis
$categorias = $conn->query("SELECT * FROM categorias")->fetchAll(PDO::FETCH_ASSOC);

// Verificar se categorias foram recuperadas
if (empty($categorias)) {
    $erro = "Nenhuma categoria encontrada.";
}

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Gerenciar Produtos</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            flex-direction: column;
        }

        .container {
            width: 95%;
            max-width: 1200px;
            background-color: #2c3e50;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            color: white;
        }

        h1 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 20px;
            color: #e74c3c;
        }

        form {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            margin-bottom: 30px;
        }

        input, select, button {
            padding: 12px;
            margin: 8px 0;
            border-radius: 8px;
            border: 1px solid #ccc;
            background-color: #34495e;
            color: white;
            width: 100%;
            max-width: 350px;
        }

        button {
            background-color: #e74c3c;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #c0392b;
        }

        .message, .error {
            text-align: center;
            padding: 15px;
            margin: 20px 0;
            border-radius: 8px;
        }

        .message {
            background-color: #27ae60;
            color: white;
        }

        .error {
            background-color: #e74c3c;
            color: white;
        }

        table {
            width: 100%;
            margin-top: 30px;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }

        th {
            background-color: #e74c3c;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #34495e;
        }

        tr:nth-child(odd) {
            background-color: #2c3e50;
        }

        .actions {
            display: flex;
            justify-content: space-between;
            gap: 10px;
        }

        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 12px 20px;
            background-color: #16a085;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: background-color 0.3s;
        }

        .back-button:hover {
            background-color: #1abc9c;
        }

        @media (max-width: 768px) {
            form {
                flex-direction: column;
                align-items: center;
            }

            input, select, button {
                width: 100%;
            }

            .container {
                padding: 20px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Gerenciar Produtos</h1>

    <?php if (isset($sucesso)): ?>
        <div class="message"><?php echo $sucesso; ?></div>
    <?php endif; ?>
    <?php if (isset($erro)): ?>
        <div class="error"><?php echo $erro; ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <input type="hidden" name="produto_id" value="<?php echo isset($produto_id) ? $produto_id : ''; ?>">
        <input type="text" name="nome" placeholder="Nome do Produto" required>
        <input type="number" name="quantidade" placeholder="Quantidade" required>
        <input type="date" name="validade" required>
        <input type="number" step="0.01" name="preco_compra" placeholder="Preço de Compra" required>
        <input type="number" step="0.01" name="preco_venda" placeholder="Preço de Venda" required>

        <?php if (!empty($categorias)): ?>
            <select name="categoria_id" required>
                <option value="">Selecione a Categoria</option>
                <?php foreach ($categorias as $categoria): ?>
                    <option value="<?php echo $categoria['id']; ?>"><?php echo htmlspecialchars($categoria['nome']); ?></option>
                <?php endforeach; ?>
            </select>
        <?php else: ?>
            <div class="error">Nenhuma categoria disponível.</div>
        <?php endif; ?>

        <button type="submit" name="atualizar">Adicionar/Repor Produto</button>
    </form>

    <h2>Produtos Cadastrados</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Quantidade</th>
                <th>Validade</th>
                <th>Preço de Compra</th>
                <th>Preço de Venda</th>
                <th>Lucro Estimado</th>
                <th>Categoria</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($produtos as $produto): ?>
                <tr>
                    <td><?php echo $produto['id']; ?></td>
                    <td><?php echo htmlspecialchars($produto['nome']); ?></td>
                    <td><?php echo $produto['quantidade']; ?></td>
                    <td><?php echo date('d/m/Y', strtotime($produto['validade'])); ?></td>
                    <td>R$ <?php echo number_format($produto['preco_compra'], 2, ',', '.'); ?></td>
                    <td>R$ <?php echo number_format($produto['preco_venda'], 2, ',', '.'); ?></td>
                    <td>R$ <?php echo number_format(($produto['preco_venda'] - $produto['preco_compra']) * $produto['quantidade'], 2, ',', '.'); ?></td>
                    <td><?php echo htmlspecialchars($produto['categoria']); ?></td>
                    <td class="actions">
                        <form method="POST" action="" style="display: inline;">
                            <input type="hidden" name="produto_id" value="<?php echo $produto['id']; ?>">
                            <input type="number" name="quantidade" min="1" value="1" required>
                            <button type="submit" name="retirar">Retirar</button>
                        </form>
                        <form method="POST" action="" style="display: inline;">
                            <input type="hidden" name="produto_id" value="<?php echo $produto['id']; ?>">
                            <input type="hidden" name="nome" value="<?php echo htmlspecialchars($produto['nome']); ?>">
                            <input type="number" name="quantidade" min="1" value="1" required>
                            <input type="date" name="validade" value="<?php echo $produto['validade']; ?>" required>
                            <input type="number" step="0.01" name="preco_compra" value="<?php echo $produto['preco_compra']; ?>" required>
                            <input type="number" step="0.01" name="preco_venda" value="<?php echo $produto['preco_venda']; ?>" required>
                            <select name="categoria_id" required>
                                <option value="<?php echo $produto['categoria_id']; ?>"><?php echo htmlspecialchars($produto['categoria']); ?></option>
                                <?php foreach ($categorias as $categoria): ?>
                                    <option value="<?php echo $categoria['id']; ?>"><?php echo htmlspecialchars($categoria['nome']); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" name="atualizar">Atualizar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <a href="admin.php" class="back-button">Voltar ao Painel Admin</a>
</div>

</body>
</html>
