<?php
include 'conexao.php';
session_start();

// Verifica se o admin está logado
if (!isset($_SESSION['loggedin']) || $_SESSION['perfil'] != 'admin') {
    header('Location: login.php');
    exit;
}

// Verificar se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Captura os dados do formulário
    $usuario_id = $_POST['usuario_id'];
    $assunto = $_POST['assunto'];
    $mensagem = $_POST['mensagem'];

    // Insere a mensagem no banco de dados
    $query = "INSERT INTO mensagens (usuario_id, assunto, mensagem) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->execute([$usuario_id, $assunto, $mensagem]);

    // Mensagem de sucesso
    $success_message = "Mensagem enviada com sucesso!";
}

// Buscar todos os usuários para mostrar no formulário
$query = "SELECT id, nome FROM usuarios";
$usuarios = $conn->query($query)->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Enviar Mensagem</title>
    <style>
        /* Estilos básicos */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        label {
            font-weight: bold;
        }
        input, textarea, select {
            padding: 10px;
            font-size: 16px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            padding: 10px;
            background-color: #5a2d91;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #4e1b6d;
        }
        .success-message {
            background-color: #d4edda;
            color: #155724;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Enviar Mensagem ao Cliente</h1>
        
        <!-- Exibir mensagem de sucesso -->
        <?php if (isset($success_message)): ?>
            <div class="success-message"><?= $success_message ?></div>
        <?php endif; ?>

        <!-- Formulário para enviar a mensagem -->
        <form action="mensagens.php" method="POST">
            <label for="usuario_id">Selecionar Usuário</label>
            <select name="usuario_id" id="usuario_id" required>
                <option value="">Selecione o Usuário</option>
                <?php foreach ($usuarios as $usuario): ?>
                    <option value="<?= $usuario['id'] ?>"><?= htmlspecialchars($usuario['nome']) ?></option>
                <?php endforeach; ?>
            </select>

            <label for="assunto">Assunto</label>
            <input type="text" name="assunto" id="assunto" required>

            <label for="mensagem">Mensagem</label>
            <textarea name="mensagem" id="mensagem" rows="6" required></textarea>

            <button type="submit">Enviar Mensagem</button>
        </form>
    </div>
</body>
</html>
