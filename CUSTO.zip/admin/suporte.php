<?php
include 'conexao.php';
session_start();

// Verifica se o admin está logado
if (!isset($_SESSION['loggedin']) || $_SESSION['perfil'] != 'admin') {
    header('Location: login.php');
    exit;
}

// Buscar todos os tickets de suporte
$query = "SELECT s.id, s.assunto, s.mensagem, s.status, s.data_envio, u.nome AS usuario
          FROM suporte s
          JOIN usuarios u ON s.usuario_id = u.id
          ORDER BY s.data_envio DESC";
$suportes = $conn->query($query)->fetchAll(PDO::FETCH_ASSOC);

// Se o administrador responder a uma mensagem
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['resposta'])) {
    $ticket_id = $_POST['ticket_id'];
    $resposta = $_POST['resposta'];
    
    // Atualiza a resposta do administrador e marca o ticket como resolvido
    $query_update = "UPDATE suporte SET resposta = ?, status = 'Resolvido', data_resposta = CURRENT_TIMESTAMP WHERE id = ?";
    $stmt = $conn->prepare($query_update);
    $stmt->execute([$resposta, $ticket_id]);

    // Mensagem de sucesso
    $success_message = "Resposta enviada e ticket marcado como resolvido!";
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Gerenciar Suporte</title>
    <style>
        /* Estilos do painel */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
            color: #333;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .form-container {
            margin-top: 20px;
        }
        textarea {
            width: 100%;
            height: 150px;
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            padding: 10px 20px;
            background-color: #5a2d91;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background-color: #4e1b6d;
        }
        .success-message {
            background-color: #d4edda;
            color: #155724;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Tickets de Suporte</h1>

        <!-- Exibir mensagem de sucesso -->
        <?php if (isset($success_message)): ?>
            <div class="success-message"><?= $success_message ?></div>
        <?php endif; ?>

        <!-- Tabela com os tickets de suporte -->
        <table>
            <tr>
                <th>ID</th>
                <th>Usuário</th>
                <th>Assunto</th>
                <th>Status</th>
                <th>Data de Envio</th>
                <th>Ações</th>
            </tr>
            <?php foreach ($suportes as $suporte): ?>
                <tr>
                    <td><?= $suporte['id'] ?></td>
                    <td><?= htmlspecialchars($suporte['usuario']) ?></td>
                    <td><?= htmlspecialchars($suporte['assunto']) ?></td>
                    <td><?= $suporte['status'] ?></td>
                    <td><?= date('d/m/Y H:i:s', strtotime($suporte['data_envio'])) ?></td>
                    <td><a href="responder_suporte.php?ticket_id=<?= $suporte['id'] ?>">Responder</a></td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>
