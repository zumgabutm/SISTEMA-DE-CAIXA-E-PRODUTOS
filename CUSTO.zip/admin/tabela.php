<?php
include '../conexao.php';
session_start();

// Verifica se o usuário está logado e é admin
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

// Ação para limpar todos os produtos
if (isset($_POST['limpar_produtos'])) {
    try {
        // Inicia a transação (para garantir que a operação seja segura)
        $conn->beginTransaction();

        // Apaga todos os produtos da tabela produtos
        $stmt = $conn->prepare("DELETE FROM produtos");
        $stmt->execute();

        // Confirma a transação
        $conn->commit();

        // Mensagem de sucesso
        $_SESSION['sucesso'] = 'Todos os produtos foram removidos com sucesso!';
        header('Location: visualizar_produtos.php');
        exit;
    } catch (Exception $e) {
        // Caso algo dê errado, faz o rollback da transação
        $conn->rollBack();
        $_SESSION['erro'] = 'Ocorreu um erro ao limpar os produtos: ' . $e->getMessage();
        header('Location: visualizar_produtos.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Limpar Todos os Produtos</title>
    <style>
        /* Estilos do painel */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(270deg, #2c003e, #5a2d91, #6a1b9a, #ab47bc, #4e1b6d, #3f0058, #0a0022, #5a2d91);
            background-size: 400% 400%;
            animation: gradientAnimation 15s ease infinite;
            margin: 0;
            padding: 20px;
            color: #ffffff;
        }

        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            25% { background-position: 50% 50%; }
            50% { background-position: 100% 50%; }
            75% { background-position: 50% 50%; }
            100% { background-position: 0% 50%; }
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .main-content {
            background-color: #2a2a2a;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        h1 {
            margin-bottom: 20px;
        }

        .button-limpar {
            background-color: #ff4757;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .button-limpar:hover {
            background-color: #ff6b81;
        }

        .notification {
            padding: 10px;
            margin-top: 20px;
            text-align: center;
            border-radius: 5px;
        }

        .success {
            background-color: #28a745;
            color: white;
        }

        .error {
            background-color: #dc3545;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="main-content">
            <h1>Limpar Todos os Produtos</h1>

            <!-- Exibe feedback de sucesso ou erro -->
            <?php if (isset($_SESSION['sucesso'])): ?>
                <div class="notification success">
                    <p><?php echo $_SESSION['sucesso']; ?></p>
                </div>
                <?php unset($_SESSION['sucesso']); ?>
            <?php elseif (isset($_SESSION['erro'])): ?>
                <div class="notification error">
                    <p><?php echo $_SESSION['erro']; ?></p>
                </div>
                <?php unset($_SESSION['erro']); ?>
            <?php endif; ?>

            <form method="POST" action="limpar_produtos.php">
                <p>Tem certeza de que deseja limpar todos os produtos da tabela?</p>
                <button type="submit" name="limpar_produtos" class="button-limpar">Sim, limpar todos os produtos</button>
            </form>
        </div>
    </div>
</body>
</html>
