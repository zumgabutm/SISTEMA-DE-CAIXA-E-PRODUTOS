<?php
include '../conexao.php';
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

// Verificar se a remoção de produto foi solicitada
if (isset($_POST['remove_id'])) {
    $produto_id = $_POST['remove_id'];

    // Verificar se o produto tem retiradas associadas
    $check_query = "SELECT COUNT(*) FROM retiradas WHERE produto_id = ?";
    $stmt = $conn->prepare($check_query);
    $stmt->execute([$produto_id]);
    $count = $stmt->fetchColumn();

    if ($count > 0) {
        $error_message = "Não é possível remover este produto, pois ele possui retiradas associadas.";
    } else {
        // Remover o produto
        $delete_query = "DELETE FROM produtos WHERE id = ?";
        $stmt = $conn->prepare($delete_query);
        $stmt->execute([$produto_id]);
        $success_message = "Produto removido com sucesso!";
    }
}

// Buscar produtos e suas retiradas
$query = "
    SELECT p.id, p.nome, p.quantidade, 
           COALESCE(SUM(r.quantidade), 0) AS total_retiradas,
           (p.quantidade - COALESCE(SUM(r.quantidade), 0)) AS quantidade_atual
    FROM produtos p
    LEFT JOIN retiradas r ON p.id = r.produto_id
    GROUP BY p.id
";

try {
    $produtos = $conn->query($query)->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Erro ao buscar produtos: " . $e->getMessage();
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Visualizar Produtos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(270deg, #2c003e, #5a2d91, #6a1b9a, #ab47bc, #4e1b6d, #3f0058, #0a0022, #5a2d91);
            color: #ffffff;
            padding: 20px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .search-container {
            margin-bottom: 20px;
        }

        .search-container input {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #444;
            background-color: #333;
            color: white;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 15px;
            border: 1px solid #444;
            text-align: left;
            background-color: #333;
        }

        th {
            background: linear-gradient(to right, #6a1b9a, #ab47bc);
            color: white;
            font-weight: bold;
            text-transform: uppercase;
        }

        td.normal {
            color: white;
        }

        td.baixo-estoque {
            color: yellow;
        }

        td.critico {
            color: red;
        }

        tr:hover td {
            background-color: #444;
        }

        .back-button {
            color: white;
            background-color: #6a1b9a;
            padding: 10px 15px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s;
            display: inline-block;
            margin-top: 20px;
            text-align: center;
        }

        .back-button:hover {
            background-color: #4e1b6d;
        }

        .remove-button {
            color: white;
            background-color: #d32f2f;
            padding: 5px 10px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s;
        }

        .remove-button:hover {
            background-color: #b71c1c;
        }
    </style>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const searchBar = document.getElementById("search-bar");
            const rows = document.querySelectorAll("table tr:not(:first-child)"); // Exclui o cabeçalho da tabela

            searchBar.addEventListener("input", function() {
                const searchTerm = searchBar.value.toLowerCase();

                rows.forEach(function(row) {
                    const cells = row.querySelectorAll("td");
                    let found = false;
                    cells.forEach(function(cell) {
                        if (cell.textContent.toLowerCase().includes(searchTerm)) {
                            found = true;
                        }
                    });
                    row.style.display = found ? "" : "none"; // Mostra ou esconde a linha
                });
            });
        });
    </script>
</head>
<body>
    <h1>Visualizar Produtos</h1>

    <!-- Exibe mensagens de sucesso ou erro -->
    <?php if (isset($success_message)): ?>
        <div style="color: green; text-align: center;"><?php echo $success_message; ?></div>
    <?php elseif (isset($error_message)): ?>
        <div style="color: red; text-align: center;"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <div class="search-container">
        <input type="text" id="search-bar" placeholder="Pesquisar produtos...">
    </div>

    <table>
        <tr>
            <th>ID</th>
            <th>Nome do Produto</th>
            <th>Quantidade Inicial</th>
            <th>Total Retiradas</th>
            <th>Quantidade Atual</th>
            <th>Ações</th> <!-- Coluna de ações para remover -->
        </tr>
        <?php foreach ($produtos as $produto): ?>
        <tr>
            <td><?php echo $produto['id']; ?></td>
            <td><?php echo htmlspecialchars($produto['nome']); ?></td>
            <td><?php echo number_format($produto['quantidade']); ?></td>
            <td><?php echo number_format($produto['total_retiradas']); ?></td>
            <td class="<?php 
                if ($produto['quantidade_atual'] <= 5) {
                    echo 'critico';
                } elseif ($produto['quantidade_atual'] < 11) {
                    echo 'baixo-estoque';
                } else {
                    echo 'normal';
                }
            ?>">
                <?php echo number_format($produto['quantidade_atual']); ?>
            </td>
            <td>
                <!-- Botão para remover produto -->
                <form method="POST" action="" onsubmit="return confirm('Você tem certeza que deseja remover este produto?');">
                    <input type="hidden" name="remove_id" value="<?php echo $produto['id']; ?>">
                    <button type="submit" class="remove-button">Remover</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <a href="admin.php" class="back-button">Voltar ao Painel Admin</a>
</body>
</html>
