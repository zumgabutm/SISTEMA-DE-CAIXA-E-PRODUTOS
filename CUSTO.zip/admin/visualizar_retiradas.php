<?php
include '../conexao.php';
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

// Obter todas as retiradas
$query = "
    SELECT r.id, r.usuario_id, u.nome AS nome_usuario, p.nome AS nome_produto, r.quantidade, r.data_retirada
    FROM retiradas r
    JOIN usuarios u ON r.usuario_id = u.id
    JOIN produtos p ON r.produto_id = p.id
    ORDER BY r.data_retirada DESC
";

$retiradas = $conn->query($query)->fetchAll(PDO::FETCH_ASSOC);

// Processar a remoção do histórico
if (isset($_POST['zerar_historico'])) {
    $usuario_id = $_POST['usuario_id'];

    // Remover todas as retiradas do usuário
    $stmt = $conn->prepare("DELETE FROM retiradas WHERE usuario_id = ?");
    $stmt->execute([$usuario_id]);

    // Mensagem de sucesso
    $sucesso = "Histórico zerado com sucesso!";
    header('Location: visualizar_retiradas.php'); // Redirecionar após a remoção
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Visualizar Retiradas</title>
    <style>
        /* Resetando estilos padrões */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            flex-direction: column;
            background: linear-gradient(90deg, #ff7e5f, #feb47b);
            background-size: 400% 400%;
            animation: gradientAnimation 15s ease infinite;
        }

        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        h1 {
            font-size: 2.5rem;
            margin-bottom: 20px;
            color: #fff;
            text-align: center;
            font-weight: bold;
        }

        .container {
            background: #fff;
            width: 80%;
            max-width: 1200px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-top: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        th {
            background-color: #ff7e5f;
            color: white;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: bold;
        }

        td {
            background-color: #fff;
            color: #555;
            transition: background-color 0.3s ease;
        }

        tr:hover td {
            background-color: #f9f9f9;
        }

        .quantidade {
            color: #ffcc00;
            font-weight: bold;
        }

        .low-stock {
            color: #ff3333;
        }

        button {
            background-color: #ff7e5f;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #feb47b;
        }

        a {
            display: inline-block;
            margin-top: 20px;
            background-color: #ff7e5f;
            color: white;
            padding: 12px 20px;
            text-decoration: none;
            text-align: center;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        a:hover {
            background-color: #feb47b;
        }

        .message {
            color: green;
            text-align: center;
            margin-bottom: 20px;
        }

        /* Estilos para dispositivos móveis */
        @media (max-width: 768px) {
            .container {
                width: 90%;
                padding: 15px;
            }

            table, th, td {
                font-size: 14px;
            }

            button {
                padding: 8px 16px;
                font-size: 14px;
            }
        }
    </style>
</head>
<body>

    <h1>MINHAS VENDAS</h1>

    <?php if (isset($sucesso)): ?>
        <div class="message"><?php echo $sucesso; ?></div>
    <?php endif; ?>

    <div class="container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome do Usuário</th>
                    <th>Produto</th>
                    <th>Quantidade</th>
                    <th>Data da Retirada</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($retiradas as $retirada): ?>
                    <tr>
                        <td><?php echo $retirada['id']; ?></td>
                        <td><?php echo $retirada['nome_usuario']; ?></td>
                        <td><?php echo $retirada['nome_produto']; ?></td>
                        <td class="<?php echo $retirada['quantidade'] < 12 ? 'low-stock' : 'quantidade'; ?>">
                            <?php echo $retirada['quantidade']; ?>
                        </td>
                        <td><?php echo date('d/m/Y H:i:s', strtotime($retirada['data_retirada'])); ?></td>
                        <td>
                            <form method="POST" action="" style="display: inline;">
                                <input type="hidden" name="usuario_id" value="<?php echo $retirada['usuario_id']; ?>">
                                <button type="submit" name="zerar_historico" onclick="return confirm('Tem certeza que deseja zerar o histórico deste usuário?');">Zerar Histórico</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <a href="admin.php">Voltar ao Painel Admin</a>
    </div>

</body>
</html>
