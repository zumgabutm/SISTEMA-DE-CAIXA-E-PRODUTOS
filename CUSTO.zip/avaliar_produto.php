<?php
include 'conexao.php';
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');  // Redireciona para login se não estiver logado
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$produto_id = $_GET['produto_id'];  // O ID do produto que o usuário quer avaliar

// Buscar os detalhes do produto
$stmt_produto = $conn->prepare("SELECT * FROM produtos WHERE id = ?");
$stmt_produto->execute([$produto_id]);
$produto = $stmt_produto->fetch(PDO::FETCH_ASSOC);

// Verificar se o produto existe
if (!$produto) {
    echo "Produto não encontrado.";
    exit;
}

// Processar o envio da avaliação
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $rating = $_POST['rating'];
    $comentario = $_POST['comentario'];

    // Verificar se o usuário já avaliou este produto
    $stmt_check = $conn->prepare("SELECT * FROM avaliacoes WHERE usuario_id = ? AND produto_id = ?");
    $stmt_check->execute([$usuario_id, $produto_id]);
    $avaliacao_existente = $stmt_check->fetch(PDO::FETCH_ASSOC);

    if ($avaliacao_existente) {
        // Se já existir uma avaliação, atualize-a
        $stmt_update = $conn->prepare("UPDATE avaliacoes SET rating = ?, comentario = ?, data_avaliacao = NOW() WHERE usuario_id = ? AND produto_id = ?");
        $stmt_update->execute([$rating, $comentario, $usuario_id, $produto_id]);
    } else {
        // Se não existir, insira uma nova avaliação
        $stmt_insert = $conn->prepare("INSERT INTO avaliacoes (usuario_id, produto_id, rating, comentario) VALUES (?, ?, ?, ?)");
        $stmt_insert->execute([$usuario_id, $produto_id, $rating, $comentario]);
    }

    echo "Avaliação enviada com sucesso!";
    // Redirecionar para a página do produto (ou outra página)
    header("Location: produto.php?id=$produto_id");
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Avaliar Produto</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .produto-info {
            margin-bottom: 20px;
        }
        .produto-info img {
            width: 100%;
            max-width: 300px;
            display: block;
            margin: auto;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            font-weight: bold;
        }
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .rating input {
            margin-right: 10px;
        }
        button {
            background-color: #6a1b9a;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #4e1b6d;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Avaliar Produto</h1>

        <div class="produto-info">
            <h2><?php echo htmlspecialchars($produto['nome']); ?></h2>
            <img src="<?php echo $produto['imagem']; ?>" alt="Imagem do Produto">
            <p><strong>Preço:</strong> R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>
            <p><strong>Descrição:</strong> <?php echo htmlspecialchars($produto['descricao']); ?></p>
        </div>

        <h3>Deixe sua Avaliação</h3>

        <!-- Formulário de avaliação -->
        <form method="POST" action="avaliar_produto.php?produto_id=<?php echo $produto_id; ?>">
            <div class="form-group">
                <label for="rating">Nota (1 a 5):</label>
                <div class="rating">
                    <input type="radio" name="rating" value="1" required> 1
                    <input type="radio" name="rating" value="2"> 2
                    <input type="radio" name="rating" value="3"> 3
                    <input type="radio" name="rating" value="4"> 4
                    <input type="radio" name="rating" value="5"> 5
                </div>
            </div>

            <div class="form-group">
                <label for="comentario">Comentário (opcional):</label>
                <textarea name="comentario" rows="5"></textarea>
            </div>

            <button type="submit">Enviar Avaliação</button>
        </form>
    </div>
</body>
</html>
