<?php
include 'conexao.php'; // Conectando ao banco de dados
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['loggedin'])) {
    header('Location: index.php'); // Redireciona para login se não estiver logado
    exit;
}

// Variáveis de busca
$busca_nome = '';
$busca_categoria = '';

// Lógica de busca de produtos
$query = "SELECT p.*, c.nome AS categoria_nome FROM produtos p 
          LEFT JOIN categorias c ON p.categoria_id = c.id 
          WHERE 1"; // Ajustado para buscar a categoria do produto com LEFT JOIN

// Verifica se há pesquisa por nome
if (isset($_GET['nome']) && !empty($_GET['nome'])) {
    $busca_nome = $_GET['nome'];
    $query .= " AND p.nome LIKE :nome"; // Busca pelo nome do produto
}

// Verifica se há pesquisa por categoria
if (isset($_GET['categoria']) && !empty($_GET['categoria'])) {
    $busca_categoria = $_GET['categoria'];
    $query .= " AND c.nome LIKE :categoria"; // Busca pela categoria
}

// Prepara a consulta
$stmt = $conn->prepare($query);

// Vincula os parâmetros da pesquisa
if (!empty($busca_nome)) {
    $stmt->bindValue(':nome', '%' . $busca_nome . '%');
}
if (!empty($busca_categoria)) {
    $stmt->bindValue(':categoria', '%' . $busca_categoria . '%');
}

// Executa a consulta
$stmt->execute();
$produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscar Produtos</title>
    <style>
        /* Estilos para a página de busca de produtos */
        body {
            font-family: Arial, sans-serif;
            background-color: #2a2a2a;
            color: white;
            padding: 20px;
            margin: 0;
        }
        .container {
            max-width: 900px;
            margin: auto;
            background: #333;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }
        h1 {
            color: #5a2d91;
            text-align: center;
        }
        form {
            margin-bottom: 20px;
            text-align: center;
        }
        input[type="text"], select {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #444;
            background-color: #444;
            color: white;
        }
        button {
            background-color: #5a2d91;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #6a2d91;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 15px;
            border: 1px solid #444;
            text-align: left;
        }
        th {
            background-color: #5a2d91;
            color: white;
        }
        td {
            background-color: #3a3a3a;
        }
        tr:hover td {
            background-color: #444;
        }
        a {
            color: #5a2d91;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Buscar Produtos</h1>

    <!-- Formulário de Busca -->
    <form method="GET" action="buscar_produtos.php">
        <input type="text" name="nome" placeholder="Buscar por nome..." value="<?php echo htmlspecialchars($busca_nome); ?>">
        <select name="categoria">
            <option value="">Escolha uma Categoria</option>
            <?php
            // Consultar categorias disponíveis para exibição
            $categorias = $conn->query("SELECT id, nome FROM categorias")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($categorias as $categoria) {
                echo "<option value=\"" . htmlspecialchars($categoria['nome']) . "\" " .
                     (($busca_categoria == $categoria['nome']) ? 'selected' : '') . ">" . 
                     htmlspecialchars($categoria['nome']) . "</option>";
            }
            ?>
        </select>
        <button type="submit">Buscar</button>
    </form>

    <!-- Exibição de Produtos -->
    <?php if (count($produtos) > 0): ?>
        <table>
            <tr>
                <th>ID</th>
                <th>Produto</th>
                <th>Categoria</th>
                <th>Preço</th>
                <th>Quantidade</th>
                <th>Ações</th>
            </tr>
            <?php foreach ($produtos as $produto): ?>
            <tr>
                <td><?php echo $produto['id']; ?></td>
                <td><?php echo htmlspecialchars($produto['nome']); ?></td>
                <td><?php echo isset($produto['categoria_nome']) ? htmlspecialchars($produto['categoria_nome']) : 'N/A'; ?></td>
                <td>R$ <?php echo isset($produto['preco']) ? number_format($produto['preco'], 2, ',', '.') : '0,00'; ?></td>
                <td><?php echo isset($produto['quantidade']) ? $produto['quantidade'] : '0'; ?></td>
                <td>
                    <a href="visualizar_produto.php?id=<?php echo $produto['id']; ?>">Ver Detalhes</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>Nenhum produto encontrado.</p>
    <?php endif; ?>
    
    <a href="home.php">Voltar para a Home</a>
</div>

</body>
</html>
