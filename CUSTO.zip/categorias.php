<?php
include 'conexao.php';  // Inclui o arquivo de conexão com o banco de dados
session_start();

// Verifica se o usuário está logado como administrador
if (!isset($_SESSION['loggedin']) || $_SESSION['tipo_usuario'] !== 'admin') {
    header('Location: login.php'); // Se não estiver logado como admin, redireciona para a página de login
    exit;
}

// Inserir nova categoria
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['nome_categoria'])) {
    $nome_categoria = $_POST['nome_categoria'];
    $descricao_categoria = $_POST['descricao_categoria'];

    // Prepara e executa o comando para inserir a categoria no banco de dados
    $stmt = $conn->prepare("INSERT INTO categorias (nome, descricao) VALUES (?, ?)");
    $stmt->execute([$nome_categoria, $descricao_categoria]);

    $_SESSION['success'] = "Categoria criada com sucesso!";
    header('Location: categorias.php');
    exit;
}

// Buscar todas as categorias
$query = "SELECT * FROM categorias ORDER BY nome";
$categorias = $conn->query($query)->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Categorias</title>
    <style>
        /* Estilos do painel */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(270deg, #2c003e, #5a2d91, #6a1b9a, #ab47bc, #4e1b6d, #3f0058, #0a0022, #5a2d91);
            background-size: 400% 400%;
            animation: gradientAnimation 15s ease infinite;
            margin: 0;
            padding: 20px;
            color: #ffffff;
        }
        .container {
            display: flex;
        }
        .sidebar {
            width: 200px;
            background-color: #1a1a1a;
            color: white;
            padding: 20px;
            border-radius: 5px;
            margin-right: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
        }
        .sidebar h2 {
            margin: 0 0 10px;
        }
        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }
        .sidebar ul li {
            margin: 10px 0;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            padding: 8px;
            display: block;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .sidebar ul li a:hover {
            background-color: #4e1b6d;
        }
        .main-content {
            flex: 1;
            background-color: #2a2a2a;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 15px;
            border: 1px solid #444;
            text-align: left;
        }
        th {
            background: linear-gradient(to right, #6a1b9a, #ab47bc);
            color: white;
            font-weight: bold;
            text-transform: uppercase;
        }
        td {
            background-color: #333;
        }
        tr:hover td {
            background-color: #444;
        }
        .form-container {
            background-color: #333;
            padding: 20px;
            border-radius: 5px;
            width: 100%;
            margin-top: 20px;
        }
        input[type="text"], input[type="submit"], textarea {
            padding: 10px;
            margin: 10px 0;
            width: 100%;
            border: 1px solid #444;
            background-color: #555;
            color: white;
            border-radius: 5px;
        }
        input[type="submit"] {
            background-color: #6a1b9a;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #5a2d91;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>Painel de Controle</h2>
            <ul>
                <li><a href="admin.php">HOME</a></li>
                <li><a href="inserir_produto.php">Inserir Produtos</a></li>
                <li><a href="categorias.php">Gerenciar Categorias</a></li> <!-- Link para categorias -->
                <li><a href="visualizar_retiradas.php">Visualizar Retiradas</a></li>
                <li><a href="index.php">Sair</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <h1>Gerenciar Categorias</h1>

            <!-- Exibe mensagem de sucesso -->
            <?php if (isset($_SESSION['success'])): ?>
                <div style="color: green; text-align: center;">
                    <?php echo $_SESSION['success']; ?>
                    <?php unset($_SESSION['success']); ?>
                </div>
            <?php endif; ?>

            <!-- Formulário para adicionar nova categoria -->
            <div class="form-container">
                <h3>Adicionar Nova Categoria</h3>
                <form method="POST">
                    <label for="nome_categoria">Nome da Categoria:</label>
                    <input type="text" name="nome_categoria" id="nome_categoria" required>

                    <label for="descricao_categoria">Descrição:</label>
                    <textarea name="descricao_categoria" id="descricao_categoria" rows="4" required></textarea>

                    <input type="submit" value="Adicionar Categoria">
                </form>
            </div>

            <!-- Tabela com as categorias existentes -->
            <table>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Descrição</th>
                    <th>Data de Criação</th>
                    <th>Ações</th>
                </tr>
                <?php if ($categorias): ?>
                    <?php foreach ($categorias as $categoria): ?>
                    <tr>
                        <td><?php echo $categoria['id']; ?></td>
                        <td><?php echo htmlspecialchars($categoria['nome']); ?></td>
                        <td><?php echo htmlspecialchars($categoria['descricao']); ?></td>
                        <td><?php echo date('d/m/Y H:i:s', strtotime($categoria['data_criacao'])); ?></td>
                        <td>
                            <!-- Excluir categoria -->
                            <a href="excluir_categoria.php?id=<?php echo $categoria['id']; ?>" style="color: red;">Excluir</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5">Nenhuma categoria encontrada.</td>
                    </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>
</body>
</html>
