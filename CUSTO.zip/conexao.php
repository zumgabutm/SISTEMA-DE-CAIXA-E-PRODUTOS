<?php
$host = 'localhost';
$db = 'rafael_db15';
$user = 'rafael_db15'; // Substitua pelo seu usuário do MySQL
$pass = 'uokoDv&3AX$5$88#3w';   // Substitua pela sua senha do MySQL

try {
    $conn = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>
