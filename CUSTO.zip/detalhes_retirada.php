<?php
include 'conexao.php';
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

// Verifica se o ID da retirada foi passado via GET
if (isset($_GET['id'])) {
    $retirada_id = $_GET['id'];

    // Buscar os detalhes da retirada
    $stmt = $conn->prepare("
        SELECT r.id, r.quantidade, r.data_retirada, p.nome AS nome_produto, u.nome AS nome_usuario
        FROM retiradas r
        JOIN produtos p ON r.produto_id = p.id
        JOIN usuarios u ON r.usuario_id = u.id
        WHERE r.id = :id
    ");
    $stmt->bindParam(':id', $retirada_id);
    $stmt->execute();
    
    // Se a retirada não existir, redireciona
    if ($stmt->rowCount() == 0) {
        header('Location: home.php');
        exit;
    }

    // Pega os dados da retirada
    $retirada = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
    header('Location: home.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalhes da Retirada</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #2a2a2a;
            color: white;
            padding: 20px;
            margin: 0;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: #333;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }
        h1 {
            text-align: center;
            color: #6a1b9a;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #444;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #6a1b9a;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #444;
        }
        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background-color: #6a1b9a;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .back-button:hover {
            background-color: #9c27b0;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Detalhes da Retirada</h1>
        
        <table>
            <tr>
                <th>Produto</th>
                <td><?php echo htmlspecialchars($retirada['nome_produto']); ?></td>
            </tr>
            <tr>
                <th>Quantidade</th>
                <td><?php echo $retirada['quantidade']; ?></td>
            </tr>
            <tr>
                <th>Data da Retirada</th>
                <td><?php echo date('d/m/Y H:i:s', strtotime($retirada['data_retirada'])); ?></td>
            </tr>
            <tr>
                <th>Usuário</th>
                <td><?php echo htmlspecialchars($retirada['nome_usuario']); ?></td>
            </tr>
        </table>
        
        <a href="visualizar_retiradas.php" class="back-button"><i class="fas fa-arrow-left"></i> Voltar para o Histórico</a>
    </div>

</body>
</html>
