<?php
include 'conexao.php';
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['loggedin'])) {
    header('Location: index.php');
    exit;
}

// Verifica se os dados de devolução foram enviados
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['produto_id']) && isset($_POST['quantidade'])) {
    $produto_id = $_POST['produto_id'];
    $quantidade = $_POST['quantidade'];
    $usuario_id = $_SESSION['usuario_id'];

    // Verifica se a quantidade solicitada é válida
    if ($quantidade > 0) {
        // Insere a devolução na tabela de devoluções
        $stmt = $conn->prepare("INSERT INTO devolucoes (usuario_id, produto_id, quantidade, data_devolucao) 
                                VALUES (?, ?, ?, NOW())");

        if ($stmt->execute([$usuario_id, $produto_id, $quantidade])) {
            // Atualiza a quantidade do produto na tabela de produtos (adiciona a devolução)
            $conn->prepare("UPDATE produtos SET quantidade = quantidade + ? WHERE id = ?")->execute([$quantidade, $produto_id]);
            $mensagem = "✅ Devolução realizada com sucesso!";
        } else {
            $mensagem = "Erro ao registrar a devolução. Tente novamente.";
        }
    } else {
        $mensagem = "Quantidade inválida.";
    }
} else {
    $mensagem = "Dados inválidos.";
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Devolução de Produto</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #1a1a1a;
            color: white;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: #2c2c2c;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            text-align: center;
            width: 90%;
            max-width: 400px;
        }
        .message {
            margin-bottom: 20px;
        }
        a {
            color: white;
            background-color: #6a1b9a;
            padding: 10px 15px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        a:hover {
            background-color: #4e1b6d;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="message"><?php echo isset($mensagem) ? htmlspecialchars($mensagem) : ''; ?></div>
        <a href="home.php">Voltar para a Home</a>
    </div>
</body>
</html>
