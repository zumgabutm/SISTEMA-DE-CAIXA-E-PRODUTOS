<?php
include 'conexao.php';
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['loggedin'])) {
    header('Location: index.php');
    exit;
}

// Obter o ID do usuário logado
$usuario_id = $_SESSION['usuario_id'];

// Buscar informações do usuário
$stmt = $conn->prepare("SELECT nome FROM usuarios WHERE id = ?");
$stmt->execute([$usuario_id]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);
$usuario_nome = $usuario['nome'] ?? 'Usuário'; // Se não encontrar o nome, atribui 'Usuário'

// Buscar produtos disponíveis
$produtos = $conn->query("SELECT * FROM produtos")->fetchAll(PDO::FETCH_ASSOC);

// Lidar com o envio do formulário de devolução
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $produto_id = $_POST['produto_id'];
    $quantidade_devolucao = $_POST['quantidade_devolucao'];

    // Verifica a quantidade que o usuário retirou
    $stmt = $conn->prepare("SELECT quantidade FROM retiradas WHERE usuario_id = ? AND produto_id = ?");
    $stmt->execute([$usuario_id, $produto_id]);
    $retirada = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($retirada) {
        $quantidade_retirada = $retirada['quantidade'];

        // Verifica se a quantidade a ser devolvida é válida
        if ($quantidade_devolucao > $quantidade_retirada) {
            $_SESSION['erro'] = "Você não pode devolver mais do que retirou.";
            header('Location: devolver_produto.php');
            exit;
        }

        // Obtém a quantidade atual do produto
        $stmt = $conn->prepare("SELECT quantidade FROM produtos WHERE id = ?");
        $stmt->execute([$produto_id]);
        $produto = $stmt->fetch(PDO::FETCH_ASSOC);

        // Atualiza a quantidade do produto somando a devolução
        $nova_quantidade = $produto['quantidade'] + $quantidade_devolucao;
        $stmt = $conn->prepare("UPDATE produtos SET quantidade = ? WHERE id = ?");
        $stmt->execute([$nova_quantidade, $produto_id]);

        // Atualiza a quantidade na tabela de retiradas
        $nova_quantidade_retirada = $quantidade_retirada - $quantidade_devolucao;
        if ($nova_quantidade_retirada > 0) {
            $stmt = $conn->prepare("UPDATE retiradas SET quantidade = ? WHERE usuario_id = ? AND produto_id = ?");
            $stmt->execute([$nova_quantidade_retirada, $usuario_id, $produto_id]);
        } else {
            // Remove a entrada se a quantidade devolvida for igual à retirada
            $stmt = $conn->prepare("DELETE FROM retiradas WHERE usuario_id = ? AND produto_id = ?");
            $stmt->execute([$usuario_id, $produto_id]);
        }

        $_SESSION['sucesso'] = "Devolução realizada com sucesso.";
        header('Location: devolver_produto.php');
        exit;
    } else {
        $_SESSION['erro'] = "Você não retirou este produto.";
        header('Location: devolver_produto.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Devolução de Produtos</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Estilo padrão */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            color: #fff;
            background-color: #2a2a2a;
            transition: all 0.3s ease-in-out;
        }
        
        /* Menu lateral */
        .sidebar {
            height: 100%;
            width: 220px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #333;
            padding-top: 20px;
            padding-left: 10px;
            border-right: 2px solid #444;
        }
        
        .sidebar a {
            display: block;
            color: white;
            padding: 12px;
            text-decoration: none;
            font-size: 18px;
            margin-bottom: 10px;
            border-radius: 4px;
        }
        
        .sidebar a:hover {
            background-color: #6a1b9a;
        }

        .main-content {
            margin-left: 240px;
            padding: 20px;
        }

        h1 {
            color: #6a1b9a;
            text-align: center;
        }

        .notification {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
            font-size: 16px;
        }

        .success {
            background-color: #28a745;
            color: white;
        }

        .error {
            background-color: #dc3545;
            color: white;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #444;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #6a1b9a;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #3a3a3a;
        }

        button {
            background-color: #6a1b9a;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease-in-out;
        }

        button:hover {
            background-color: #9c27b0;
            transform: scale(1.05);
        }

        /* Tema claro */
        body.light-mode {
            background-color: #f8f9fa;
            color: #333;
        }

        .sidebar.light-mode {
            background-color: #343a40;
        }

        /* Tema escuro (Hacker Style) */
        body.dark-mode {
            background-color: #1c1c1c;
            color: #00ff00; /* Texto verde fluorescente */
            font-family: 'Courier New', Courier, monospace; /* Fonte de terminal */
        }

        .sidebar.dark-mode {
            background-color: #000000;
            border-right: 2px solid #00ff00; /* Borda verde fluorescente */
        }

        .main-content.dark-mode {
            color: #00ff00;
        }

        /* Tema azul */
        body.blue-mode {
            background-color: #e3f2fd;
            color: #0d47a1;
        }

        .sidebar.blue-mode {
            background-color: #42a5f5;
        }

        /* Tema roxo */
        body.purple-mode {
            background-color: #f3e5f5;
            color: #6a1b9a;
        }

        .sidebar.purple-mode {
            background-color: #9c27b0;
        }

        /* Tema verde */
        body.green-mode {
            background-color: #e8f5e9;
            color: #2e7d32;
        }

        .sidebar.green-mode {
            background-color: #66bb6a;
        }

        /* Estilo do botão de alternância de tema */
        .theme-toggle {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #6a1b9a;
            border: none;
            border-radius: 50%;
            padding: 10px;
            cursor: pointer;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .theme-toggle i {
            font-size: 24px;
            color: #fff;
        }

        /* Botões para seleção de tema com ícones */
        .theme-buttons {
            position: fixed;
            top: 20px;
            right: 20px;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .theme-button {
            background-color: #fff;
            border: none;
            border-radius: 50%;
            padding: 10px;
            cursor: pointer;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .theme-button i {
            font-size: 24px;
            color: #6a1b9a;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
    <h2 style="color: white; text-align: center;">SISTEMA</h2>
    <a href="home.php">HOME</a>
    <a href="perfil.php">PERFIL</a>
    <a href="buscar_produtos.php">PESQUISAR</a>
    <a href="historico_completo.php">HISTORICO</a>
    <a href="devolver_produto.php">DEVOLVER</a>
    <a href="estoque.php">ESTOQUE</a>
   <a href="index.php">SAIR</a>
    </div>

    <!-- Conteúdo principal -->
    <div class="main-content">

        <!-- Exibir mensagens de erro ou sucesso -->
        <?php if (isset($_SESSION['sucesso'])): ?>
            <div class="notification success">
                <p><?php echo $_SESSION['sucesso']; ?></p>
            </div>
            <?php unset($_SESSION['sucesso']); ?>
        <?php elseif (isset($_SESSION['erro'])): ?>
            <div class="notification error">
                <p><?php echo $_SESSION['erro']; ?></p>
            </div>
            <?php unset($_SESSION['erro']); ?>
        <?php endif; ?>

        <h1>Bem-vindo, <?php echo htmlspecialchars($usuario_nome); ?></h1>

        <h2>Produtos Disponíveis</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Nome do Produto</th>
                <th>Quantidade</th>
                <th>Ação</th>
            </tr>
            <?php if ($produtos): ?>
                <?php foreach ($produtos as $produto): ?>
                <tr>
                    <td><?php echo $produto['id']; ?></td>
                    <td><?php echo htmlspecialchars($produto['nome']); ?></td>
                    <td><?php echo $produto['quantidade']; ?></td>
                    <td>
                        <form method="POST" action="devolver_produto.php">
                            <input type="hidden" name="produto_id" value="<?php echo $produto['id']; ?>">
                            <input type="number" name="quantidade_devolucao" min="1" max="<?php echo $produto['quantidade']; ?>" required>
                            <button type="submit"><i class="fa fa-undo"></i> Devolver</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4">Nenhum produto disponível.</td>
                </tr>
            <?php endif; ?>
        </table>

    </div>

    <!-- Botões de seleção de tema -->
    <div class="theme-buttons">
        <button class="theme-button light-mode" id="light-mode"><i class="fas fa-sun"></i></button>
        <button class="theme-button dark-mode" id="dark-mode"><i class="fas fa-moon"></i></button>
        <button class="theme-button blue-mode" id="blue-mode"><i class="fas fa-tint"></i></button>
        <button class="theme-button purple-mode" id="purple-mode"><i class="fas fa-magic"></i></button>
        <button class="theme-button green-mode" id="green-mode"><i class="fas fa-leaf"></i></button>
    </div>

    <!-- Scripts para persistir o tema -->
    <script>
        const applyTheme = (theme) => {
            document.body.classList.remove('light-mode', 'dark-mode', 'blue-mode', 'purple-mode', 'green-mode');
            document.querySelector('.sidebar').classList.remove('light-mode', 'dark-mode', 'blue-mode', 'purple-mode', 'green-mode');
            document.body.classList.add(theme);
            document.querySelector('.sidebar').classList.add(theme);
            localStorage.setItem('theme', theme); // Armazena o tema no localStorage
        };

        const storedTheme = localStorage.getItem('theme');
        if (storedTheme) {
            applyTheme(storedTheme);
        }

        document.getElementById('light-mode').addEventListener('click', () => applyTheme('light-mode'));
        document.getElementById('dark-mode').addEventListener('click', () => applyTheme('dark-mode'));
        document.getElementById('blue-mode').addEventListener('click', () => applyTheme('blue-mode'));
        document.getElementById('purple-mode').addEventListener('click', () => applyTheme('purple-mode'));
        document.getElementById('green-mode').addEventListener('click', () => applyTheme('green-mode'));
    </script>

</body>
</html>
