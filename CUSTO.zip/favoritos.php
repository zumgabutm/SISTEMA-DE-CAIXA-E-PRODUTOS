<?php
include 'conexao.php';
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

// Obtém o ID do usuário logado
$usuario_id = $_SESSION['usuario_id'];

// Consulta para obter os produtos favoritos do usuário logado
$query_favoritos = "
    SELECT p.id, p.nome, p.preco, p.imagem
    FROM favoritos f
    JOIN produtos p ON f.produto_id = p.id
    WHERE f.usuario_id = :usuario_id
    ORDER BY f.data_adicionado DESC
";
$stmt = $conn->prepare($query_favoritos);
$stmt->bindParam(':usuario_id', $usuario_id);
$stmt->execute();
$favoritos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Remover produto dos favoritos
if (isset($_GET['remover'])) {
    $produto_id = $_GET['remover'];

    // Remover o produto dos favoritos do usuário
    $remove_query = "DELETE FROM favoritos WHERE usuario_id = :usuario_id AND produto_id = :produto_id";
    $stmt_remove = $conn->prepare($remove_query);
    $stmt_remove->bindParam(':usuario_id', $usuario_id);
    $stmt_remove->bindParam(':produto_id', $produto_id);
    $stmt_remove->execute();

    // Redireciona de volta para a página favoritos
    header('Location: favoritos.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meus Produtos Favoritos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #2a2a2a;
            color: white;
            padding: 20px;
            margin: 0;
        }
        .container {
            max-width: 900px;
            margin: auto;
            background-color: #333;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }
        h1 {
            text-align: center;
            color: #6a1b9a;
        }
        .produto {
            display: flex;
            margin-bottom: 20px;
            padding: 10px;
            background-color: #444;
            border-radius: 5px;
        }
        .produto img {
            width: 100px;
            height: 100px;
            border-radius: 5px;
        }
        .produto-info {
            margin-left: 20px;
            flex: 1;
        }
        .produto h3 {
            margin: 0;
        }
        .produto p {
            margin: 5px 0;
        }
        .produto .remover {
            color: #ff6347;
            text-decoration: none;
            font-weight: bold;
            cursor: pointer;
        }
        .produto .remover:hover {
            color: #ff4500;
        }
        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background-color: #6a1b9a;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .back-button:hover {
            background-color: #9c27b0;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Meus Produtos Favoritos</h1>

        <!-- Exibe os produtos favoritos -->
        <?php if (count($favoritos) > 0): ?>
            <?php foreach ($favoritos as $produto): ?>
                <div class="produto">
                    <img src="<?php echo htmlspecialchars($produto['imagem']); ?>" alt="<?php echo htmlspecialchars($produto['nome']); ?>">
                    <div class="produto-info">
                        <h3><?php echo htmlspecialchars($produto['nome']); ?></h3>
                        <p>Preço: R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>
                        <a href="?remover=<?php echo $produto['id']; ?>" class="remover">Remover dos Favoritos</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Você não tem produtos favoritos.</p>
        <?php endif; ?>

        <a href="home.php" class="back-button">Voltar para a Home</a>
    </div>

</body>
</html>
