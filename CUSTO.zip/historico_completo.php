<?php
include 'conexao.php';
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');  // Redireciona para login se não estiver logado
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

// Consultar histórico de retiradas
$query_ret = "
    SELECT r.id, p.nome AS nome_produto, r.quantidade, r.data_retirada
    FROM retiradas r
    JOIN produtos p ON r.produto_id = p.id
    WHERE r.usuario_id = ?
    ORDER BY r.data_retirada DESC
";
$stmt_ret = $conn->prepare($query_ret);
$stmt_ret->execute([$usuario_id]);
$retiradas = $stmt_ret->fetchAll(PDO::FETCH_ASSOC);

// Consultar histórico de devoluções
$query_dev = "
    SELECT d.id, p.nome AS nome_produto, d.quantidade, d.data_devolucao
    FROM devolucoes d
    JOIN produtos p ON d.produto_id = p.id
    WHERE d.usuario_id = ?
    ORDER BY d.data_devolucao DESC
";
$stmt_dev = $conn->prepare($query_dev);
$stmt_dev->execute([$usuario_id]);
$devolucoes = $stmt_dev->fetchAll(PDO::FETCH_ASSOC);

// Consultar histórico de avaliações
$query_avaliacoes = "
    SELECT a.rating, p.nome AS nome_produto, a.comentario, a.data_avaliacao
    FROM avaliacoes a
    JOIN produtos p ON a.produto_id = p.id
    WHERE a.usuario_id = ?
    ORDER BY a.data_avaliacao DESC
";
$stmt_avaliacoes = $conn->prepare($query_avaliacoes);
$stmt_avaliacoes->execute([$usuario_id]);
$avaliacoes = $stmt_avaliacoes->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Histórico Completo</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 15px;
            border: 1px solid #ccc;
            text-align: left;
        }
        th {
            background-color: #6a1b9a;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #ddd;
        }
        .section {
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Histórico Completo</h1>

        <!-- Histórico de Retiradas -->
        <div class="section">
            <h2>Histórico de Retiradas</h2>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Produto</th>
                    <th>Quantidade</th>
                    <th>Data da Retirada</th>
                </tr>
                <?php if (count($retiradas) > 0): ?>
                    <?php foreach ($retiradas as $retirada): ?>
                    <tr>
                        <td><?php echo $retirada['id']; ?></td>
                        <td><?php echo htmlspecialchars($retirada['nome_produto']); ?></td>
                        <td><?php echo $retirada['quantidade']; ?></td>
                        <td><?php echo date('d/m/Y H:i:s', strtotime($retirada['data_retirada'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4">Nenhuma retirada encontrada.</td>
                    </tr>
                <?php endif; ?>
            </table>
        </div>

        <!-- Histórico de Devoluções -->
        <div class="section">
            <h2>Histórico de Devoluções</h2>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Produto</th>
                    <th>Quantidade</th>
                    <th>Data da Devolução</th>
                </tr>
                <?php if (count($devolucoes) > 0): ?>
                    <?php foreach ($devolucoes as $devolucao): ?>
                    <tr>
                        <td><?php echo $devolucao['id']; ?></td>
                        <td><?php echo htmlspecialchars($devolucao['nome_produto']); ?></td>
                        <td><?php echo $devolucao['quantidade']; ?></td>
                        <td><?php echo date('d/m/Y H:i:s', strtotime($devolucao['data_devolucao'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4">Nenhuma devolução encontrada.</td>
                    </tr>
                <?php endif; ?>
            </table>
        </div>

        <!-- Histórico de Avaliações -->
        <div class="section">
            <h2>Histórico de Avaliações</h2>
            <table>
                <tr>
                    <th>Produto</th>
                    <th>Avaliação</th>
                    <th>Comentário</th>
                    <th>Data da Avaliação</th>
                </tr>
                <?php if (count($avaliacoes) > 0): ?>
                    <?php foreach ($avaliacoes as $avaliacao): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($avaliacao['nome_produto']); ?></td>
                        <td><?php echo $avaliacao['rating']; ?> estrelas</td>
                        <td><?php echo htmlspecialchars($avaliacao['comentario']); ?></td>
                        <td><?php echo date('d/m/Y H:i:s', strtotime($avaliacao['data_avaliacao'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4">Nenhuma avaliação encontrada.</td>
                    </tr>
                <?php endif; ?>
            </table>
        </div>

    </div>
</body>
</html>
