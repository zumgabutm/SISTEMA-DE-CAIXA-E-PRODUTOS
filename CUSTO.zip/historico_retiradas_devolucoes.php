<?php
include 'conexao.php';
session_start();

if (!isset($_SESSION['loggedin'])) {
    header('Location: index.php');
    exit;
}

// Obter o ID do usuário logado
$usuario_id = $_SESSION['usuario_id'];

// Buscar histórico de devoluções do usuário logado
$query_devolucoes = "
    SELECT d.id, p.nome AS nome_produto, d.quantidade, d.data_devolucao
    FROM devolucoes d
    JOIN produtos p ON d.produto_id = p.id
    WHERE d.usuario_id = ?
    ORDER BY d.data_devolucao DESC
";

$stmt_devolucoes = $conn->prepare($query_devolucoes);
$stmt_devolucoes->execute([$usuario_id]);
$devolucoes = $stmt_devolucoes->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visualizar Meu Histórico de Devoluções</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #1a1a1a;
            color: white;
            padding: 20px;
            margin: 0;
        }
        .container {
            max-width: 900px;
            margin: auto;
            background: #2c2c2c;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }
        h1 {
            color: #5a2d91;
            text-align: center;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #444;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #5a2d91;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #3c3c3c;
        }
        tr:hover {
            background-color: #4e1b6d;
        }
        a {
            display: inline-block;
            margin-top: 20px;
            color: white;
            background-color: #6a1b9a;
            padding: 10px 15px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s;
            text-align: center;
            width: 100%;
        }
        a:hover {
            background-color: #4e1b6d;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Histórico de Devoluções</h1>
        <table>
            <tr>
                <th>ID</th>
                <th>Produto</th>
                <th>Quantidade</th>
                <th>Data da Devolução</th>
            </tr>
            <?php if (count($devolucoes) > 0): ?>
                <?php foreach ($devolucoes as $devolucao): ?>
                <tr>
                    <td><?php echo $devolucao['id']; ?></td>
                    <td><?php echo htmlspecialchars($devolucao['nome_produto']); ?></td>
                    <td><?php echo $devolucao['quantidade']; ?></td>
                    <td><?php echo date('d/m/Y H:i:s', strtotime($devolucao['data_devolucao'])); ?></td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" style="text-align: center;">Você ainda não fez nenhuma devolução.</td>
                </tr>
            <?php endif; ?>
        </table>
        <a href="home.php">Voltar para a Home</a>
    </div>
</body>
</html>
