<?php
include 'conexao.php';
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['loggedin'])) {
    header('Location: index.php');
    exit;
}

// Obter o ID e nome do usuário logado
$usuario_id = $_SESSION['usuario_id'];  // O ID do usuário deve estar na sessão

// Buscar informações do usuário para obter o nome
$stmt = $conn->prepare("SELECT nome FROM usuarios WHERE id = ?");
$stmt->execute([$usuario_id]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);
$usuario_nome = $usuario['nome'] ?? 'Usuário';

// Buscar produtos disponíveis
$produtos = $conn->query("SELECT * FROM produtos")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home do Cliente</title>

    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <!-- FontAwesome para ícones -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        /* Estilo padrão */
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            color: #333;
            font-weight: bold;  /* Todas as letras em negrito */
            transition: all 0.3s ease-in-out;
        }

        .sidebar {
            height: 100%;
            width: 220px;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 20px;
            padding-left: 10px;
            border-right: 2px solid #444;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 12px;
            text-decoration: none;
            font-size: 18px;
            margin-bottom: 10px;
            border-radius: 4px;
        }

        .sidebar a:hover {
            background-color: #6a1b9a;
        }

        .main-content {
            margin-left: 240px;
            padding: 20px;
        }

        h1, h2, .table th, .table td {
            transition: color 0.3s ease-in-out;
        }

        h1 {
            color: #6a1b9a;
            text-align: center;
        }

        h2 {
            color: #6a1b9a;
            margin-top: 30px;
        }

        .notification {
            margin-top: 20px;
        }

        /* Tema claro */
        body.light-mode {
            background-color: #f8f9fa;
            color: #333;
        }

        .sidebar.light-mode {
            background-color: #343a40;
        }

        /* Tema escuro (Hacker Style) */
        body.dark-mode {
            background-color: #1c1c1c;
            color: #00ff00; /* Texto verde fluorescente */
            font-family: 'Courier New', Courier, monospace; /* Fonte de terminal */
        }

        .sidebar.dark-mode {
            background-color: #000000;
            border-right: 2px solid #00ff00; /* Borda verde fluorescente */
        }

        .main-content.dark-mode {
            color: #00ff00;
        }

        .table.dark-mode th, .table.dark-mode td {
            color: #00ff00;
            border-color: #00ff00;
        }

        /* Tema azul */
        body.blue-mode {
            background-color: #e3f2fd;
            color: #0d47a1;
        }

        .sidebar.blue-mode {
            background-color: #42a5f5;
        }

        /* Tema roxo */
        body.purple-mode {
            background-color: #f3e5f5;
            color: #6a1b9a;
        }

        .sidebar.purple-mode {
            background-color: #9c27b0;
        }

        /* Tema verde */
        body.green-mode {
            background-color: #e8f5e9;
            color: #2e7d32;
        }

        .sidebar.green-mode {
            background-color: #66bb6a;
        }

        /* Estilo do botão de alternância de tema */
        .theme-toggle {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #6a1b9a;
            border: none;
            border-radius: 50%;
            padding: 10px;
            cursor: pointer;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .theme-toggle i {
            font-size: 24px;
            color: #fff;
        }

        /* Botões para seleção de tema com ícones */
        .theme-buttons {
            position: fixed;
            top: 20px;
            right: 20px;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .theme-button {
            background-color: #fff;
            border: none;
            border-radius: 50%;
            padding: 10px;
            cursor: pointer;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .theme-button i {
            font-size: 24px;
            color: #6a1b9a;
        }

        .theme-button:hover {
            background-color: #e1bee7;
        }

    </style>
</head>
<body class="light-mode">

    <!-- Menu lateral -->
    <div class="sidebar">
    <h2 style="color: white; text-align: center;">SISTEMA</h2>
    <a href="home.php">HOME</a>
    <a href="perfil.php">PERFIL</a>
    <a href="buscar_produtos.php">PESQUISAR</a>
    <a href="historico_completo.php">HISTORICO</a>
    <a href="devolver_produto.php">DEVOLVER</a>
    <a href="estoque.php">ESTOQUE</a>
   <a href="index.php">SAIR</a>
</div>


    <!-- Conteúdo principal -->
    <div class="main-content">
        <!-- Feedback de sucesso/erro -->
        <?php if (isset($_SESSION['sucesso'])): ?>
            <div class="alert alert-success notification" role="alert">
                <?php echo $_SESSION['sucesso']; ?>
            </div>
            <?php unset($_SESSION['sucesso']); ?>
        <?php elseif (isset($_SESSION['erro'])): ?>
            <div class="alert alert-danger notification" role="alert">
                <?php echo $_SESSION['erro']; ?>
            </div>
            <?php unset($_SESSION['erro']); ?>
        <?php endif; ?>

        <h1>Bem-vindo, <?php echo htmlspecialchars($usuario_nome); ?></h1>

        <h2>Produtos Disponíveis</h2>
        <table class="table table-striped table-bordered dark-mode">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome do Produto</th>
                    <th>Quantidade</th>
                    <th>Ação</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($produtos as $produto): ?>
                <tr>
                    <td><?php echo $produto['id']; ?></td>
                    <td><?php echo htmlspecialchars($produto['nome']); ?></td>
                    <td><?php echo $produto['quantidade']; ?></td>
                    <td>
                        <form method="POST" action="retirar_produto.php">
                            <input type="hidden" name="produto_id" value="<?php echo $produto['id']; ?>">
                            <input type="number" name="quantidade" min="1" max="<?php echo $produto['quantidade']; ?>" required>
                            <button type="submit" class="btn btn-primary"><i class="fa fa-shopping-cart"></i>NOVA-VENDA</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Botões de seleção de tema -->
    <div class="theme-buttons">
        <button class="theme-button light-mode" id="light-mode"><i class="fas fa-sun"></i></button>
        <button class="theme-button dark-mode" id="dark-mode"><i class="fas fa-moon"></i></button>
        <button class="theme-button blue-mode" id="blue-mode"><i class="fas fa-tint"></i></button>
        <button class="theme-button purple-mode" id="purple-mode"><i class="fas fa-magic"></i></button>
        <button class="theme-button green-mode" id="green-mode"><i class="fas fa-leaf"></i></button>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Função para aplicar o tema
        const applyTheme = (theme) => {
            document.body.classList.remove('light-mode', 'dark-mode', 'blue-mode', 'purple-mode', 'green-mode');
            document.querySelector('.sidebar').classList.remove('light-mode', 'dark-mode', 'blue-mode', 'purple-mode', 'green-mode');
            document.body.classList.add(theme);
            document.querySelector('.sidebar').classList.add(theme);
            localStorage.setItem('theme', theme); // Armazena o tema no localStorage
        };

        // Recupera o tema do localStorage e aplica ao carregar a página
        const storedTheme = localStorage.getItem('theme');
        if (storedTheme) {
            applyTheme(storedTheme);
        }

        // Eventos para os botões de tema
        document.getElementById('light-mode').addEventListener('click', () => applyTheme('light-mode'));
        document.getElementById('dark-mode').addEventListener('click', () => applyTheme('dark-mode'));
        document.getElementById('blue-mode').addEventListener('click', () => applyTheme('blue-mode'));
        document.getElementById('purple-mode').addEventListener('click', () => applyTheme('purple-mode'));
        document.getElementById('green-mode').addEventListener('click', () => applyTheme('green-mode'));
    </script>
</body>
</html>
