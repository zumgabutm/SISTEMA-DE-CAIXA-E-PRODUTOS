<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include 'conexao.php';

    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE email = ?");
    $stmt->execute([$email]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($usuario && password_verify($senha, $usuario['senha'])) {
        $_SESSION['loggedin'] = true;
        $_SESSION['usuario_id'] = $usuario['id'];
        header('Location: home.php');
        exit;
    } else {
        $erro = "E-mail ou senha incorretos.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login do Cliente</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #2c003e, #5a2d91); /* Gradiente suave */
            padding: 0;
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .form-container {
            background: rgba(0, 0, 0, 0.7); /* Fundo semitransparente */
            padding: 30px;
            border-radius: 20px;
            width: 170%;
            max-width: 270px;
            box-shadow: 5 8px 25px rgba(0, 0, 0, 0.4);
            text-align: center;
            position: relative;
            overflow: hidden;
            animation: fadeIn 0.9s ease-out;
        }

        /* Fundo com imagem e 30% de transparência */
        .form-container::before {
            content: "";
            background-image: url('https://i.gifer.com/5ARz.gif');
            background-size: cover; /* Faz a imagem cobrir todo o cartão */
            background-position: center center; /* Centraliza a imagem */
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: -1; /* Coloca a imagem atrás do conteúdo */
            opacity: 0.3;
        }

        h2 {
            font-size: 2.5em;
            color: #ffeb3b; /* Cor amarela */
            margin-bottom: 20px;
            animation: slideIn 0.6s ease-out;
        }

        @keyframes fadeIn {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }

        @keyframes slideIn {
            0% { transform: translateY(-30px); opacity: 0; }
            100% { transform: translateY(0); opacity: 1; }
        }

        input {
            width: 93%;
            padding: 15px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #333;
            color: white;
            font-size: 1.1em;
            transition: all 0.3s ease;
        }

        input:focus {
            border-color: #ffeb3b; /* Destacar campo em foco */
            background-color: #444;
            outline: none;
        }

        button {
            background-color: #1e3a5f; /* Nova cor azul escuro */
            color: white;
            padding: 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            font-size: 1.2em;
            transition: all 0.3s ease;
        }

        button:hover {
            background-color: #152a40;
        }

        .error {
            color: red;
            margin-top: 10px;
            font-size: 1.1em;
            animation: shake 0.5s ease-out;
        }

        @keyframes shake {
            0% { transform: translateX(-10px); }
            25% { transform: translateX(10px); }
            50% { transform: translateX(-10px); }
            75% { transform: translateX(10px); }
            100% { transform: translateX(0); }
        }

        .admin-link {
            margin-top: 20px;
            margin-bottom: 10px;
        }

        .admin-link a {
            text-decoration: none;
            color: #ffeb3b;
            font-size: 1.2em;
            padding: 10px;
            border: 1px solid #ffeb3b;
            border-radius: 5px;
            display: inline-block;
            transition: background-color 0.3s ease;
        }

        .admin-link a:hover {
            background-color: #4e1b6d;
            color: white;
        }

        /* Responsividade */
        @media (max-width: 600px) {
            .form-container {
                width: 90%;
                padding: 20px;
            }

            h2 {
                font-size: 2em;
            }

            input {
                font-size: 1em;
                padding: 12px;
            }

            button {
                font-size: 1em;
                padding: 12px;
            }
        }
    </style>
</head>
<body>
    <div class="form-container">
        <form method="POST" action="">
            <h2>Área do Cliente</h2>
            <input type="email" name="email" placeholder="E-mail" required>
            <input type="password" name="senha" placeholder="Senha" required>
            <button type="submit">Entrar</button>
            <?php if (isset($erro)) echo "<div class='error'>$erro</div>"; ?>
        </form>

        <div class="admin-link">
            <a href="admin/index.php">Entrar como Admin</a>
        </div>
    </div>
</body>
</html>
