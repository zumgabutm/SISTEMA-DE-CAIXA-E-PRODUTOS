<?php
include 'conexao.php';
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

// Obtém o ID do usuário logado
$usuario_id = $_SESSION['usuario_id'];

// Buscar as mensagens não lidas para o usuário logado
$query_mensagens = "
    SELECT m.id, u.nome AS nome_usuario, m.mensagem, m.data_envio, m.lida
    FROM mensagens m
    JOIN usuarios u ON m.usuario_id = u.id
    WHERE m.destinatario_id = :usuario_id
    ORDER BY m.data_envio DESC
";
$stmt = $conn->prepare($query_mensagens);
$stmt->bindParam(':usuario_id', $usuario_id);
$stmt->execute();
$mensagens = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Marcar as mensagens como lidas
if (isset($_GET['mark_as_read'])) {
    $mensagem_id = $_GET['mark_as_read'];

    $update_query = "
        UPDATE mensagens 
        SET lida = TRUE 
        WHERE id = :mensagem_id
    ";
    $stmt_update = $conn->prepare($update_query);
    $stmt_update->bindParam(':mensagem_id', $mensagem_id);
    $stmt_update->execute();

    header("Location: mensagens.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minhas Mensagens</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #2a2a2a;
            color: white;
            padding: 20px;
            margin: 0;
        }
        .container {
            max-width: 900px;
            margin: auto;
            background-color: #333;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }
        h1 {
            text-align: center;
            color: #6a1b9a;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #444;
        }
        th {
            background-color: #6a1b9a;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #444;
        }
        tr:hover {
            background-color: #555;
        }
        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background-color: #6a1b9a;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .back-button:hover {
            background-color: #9c27b0;
        }
        .mark-as-read {
            background-color: #4e1b6d;
            color: white;
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Minhas Mensagens</h1>

        <!-- Tabela de mensagens -->
        <table>
            <tr>
                <th>De</th>
                <th>Mensagem</th>
                <th>Data de Envio</th>
                <th>Ações</th>
            </tr>
            <?php if (count($mensagens) > 0): ?>
                <?php foreach ($mensagens as $mensagem): ?>
                <tr style="background-color: <?php echo $mensagem['lida'] ? '#444' : '#555'; ?>">
                    <td><?php echo htmlspecialchars($mensagem['nome_usuario']); ?></td>
                    <td><?php echo htmlspecialchars($mensagem['mensagem']); ?></td>
                    <td><?php echo date('d/m/Y H:i:s', strtotime($mensagem['data_envio'])); ?></td>
                    <td>
                        <?php if (!$mensagem['lida']): ?>
                            <a href="?mark_as_read=<?php echo $mensagem['id']; ?>" class="mark-as-read">Marcar como lida</a>
                        <?php else: ?>
                            <span>Já lida</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4">Nenhuma mensagem encontrada.</td>
                </tr>
            <?php endif; ?>
        </table>

        <a href="home.php" class="back-button">Voltar para a Home</a>
    </div>

</body>
</html>
