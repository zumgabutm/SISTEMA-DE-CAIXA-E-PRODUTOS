<?php
include 'conexao.php';
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');  // Redireciona para login se não estiver logado
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

// Consultar as notificações não lidas do usuário
$query = "
    SELECT id, mensagem, lida, data
    FROM notificacoes
    WHERE usuario_id = ?
    ORDER BY data DESC
";
$stmt = $conn->prepare($query);
$stmt->execute([$usuario_id]);
$notificacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Marcar as notificações como lidas
if (isset($_GET['marcar_lidas'])) {
    $update_query = "UPDATE notificacoes SET lida = TRUE WHERE usuario_id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->execute([$usuario_id]);
    header('Location: notificacoes.php');  // Recarregar a página para refletir as alterações
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notificações</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 15px;
            border: 1px solid #ccc;
            text-align: left;
        }
        th {
            background-color: #6a1b9a;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #ddd;
        }
        .status-lida {
            color: #4caf50;
        }
        .status-nao-lida {
            color: #f44336;
        }
        .mark-read {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #6a1b9a;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            text-align: center;
            transition: background-color 0.3s;
        }
        .mark-read:hover {
            background-color: #5a1b9a;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Notificações</h1>

        <?php if (count($notificacoes) > 0): ?>
            <table>
                <tr>
                    <th>Data</th>
                    <th>Mensagem</th>
                    <th>Status</th>
                </tr>
                <?php foreach ($notificacoes as $notificacao): ?>
                    <tr>
                        <td><?php echo date('d/m/Y H:i:s', strtotime($notificacao['data'])); ?></td>
                        <td><?php echo htmlspecialchars($notificacao['mensagem']); ?></td>
                        <td class="<?php echo $notificacao['lida'] ? 'status-lida' : 'status-nao-lida'; ?>">
                            <?php echo $notificacao['lida'] ? 'Lida' : 'Não Lida'; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>

            <!-- Botão para marcar todas as notificações como lidas -->
            <a href="notificacoes.php?marcar_lidas=true" class="mark-read">Marcar todas como lidas</a>
        <?php else: ?>
            <p>Você não tem notificações.</p>
        <?php endif; ?>

    </div>
</body>
</html>
