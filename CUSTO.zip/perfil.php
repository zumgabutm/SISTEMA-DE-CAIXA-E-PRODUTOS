<?php
include 'conexao.php'; // Incluindo a conexão com o banco de dados
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['loggedin'])) {
    header('Location: index.php'); // Redireciona para a página de login se o usuário não estiver logado
    exit;
}

// Obter o ID do usuário logado
$usuario_id = $_SESSION['usuario_id'];

// Buscar informações do usuário (nome e e-mail)
$query = "SELECT nome, email FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->execute([$usuario_id]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$usuario) {
    die("Usuário não encontrado!");
}

$usuario_nome = $usuario['nome'];
$usuario_email = $usuario['email'];

// Verifica se o formulário de alteração de senha foi enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['nova_senha'])) {
    $nova_senha = $_POST['nova_senha'];
    $confirmar_senha = $_POST['confirmar_senha'];

    // Verifica se as senhas coincidem
    if ($nova_senha != $confirmar_senha) {
        $erro = "As senhas não coincidem.";
    } else {
        // Atualiza a senha no banco de dados
        $hashed_senha = password_hash($nova_senha, PASSWORD_DEFAULT); // Criptografando a senha

        $update_query = "UPDATE usuarios SET senha = ? WHERE id = ?";
        $update_stmt = $conn->prepare($update_query);
        if ($update_stmt->execute([$hashed_senha, $usuario_id])) {
            $sucesso = "Senha alterada com sucesso!";
        } else {
            $erro = "Erro ao alterar a senha. Tente novamente.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meu Perfil</title>
    <style>
        /* Estilos para a página de perfil */
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #5a2d91, #9b59b6); /* Gradiente roxo */
            color: white;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            max-width: 900px;
            width: 100%;
            background: #333;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            text-align: center;
        }
        h1 {
            font-size: 2.5em;
            color: #ffbb33;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 15px;
            border: 1px solid #444;
            text-align: left;
        }
        th {
            background-color: #5a2d91;
            color: white;
        }
        td {
            background-color: #3a3a3a;
        }
        form {
            margin-top: 30px;
            display: grid;
            gap: 15px;
        }
        input[type="password"] {
            padding: 15px;
            border-radius: 8px;
            border: 1px solid #444;
            width: 100%;
            background-color: #444;
            color: white;
            font-size: 1em;
        }
        button {
            background-color: #ffbb33;
            color: #333;
            padding: 15px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1.2em;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #ff9c00;
        }
        .notification {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 1.1em;
        }
        .success {
            background-color: #28a745;
            color: white;
        }
        .error {
            background-color: #dc3545;
            color: white;
        }
        a {
            color: #ffbb33;
            text-decoration: none;
            font-size: 1.1em;
            margin-top: 20px;
            display: inline-block;
            transition: color 0.3s;
        }
        a:hover {
            color: #ff9c00;
        }

        /* Responsividade */
        @media (max-width: 768px) {
            .container {
                padding: 20px;
            }
            h1 {
                font-size: 2em;
            }
            input[type="password"] {
                font-size: 1em;
            }
            button {
                font-size: 1em;
                padding: 12px 20px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Meu Perfil</h1>

    <!-- Exibir Mensagens de Sucesso ou Erro -->
    <?php if (isset($sucesso)): ?>
        <div class="notification success"><?php echo $sucesso; ?></div>
    <?php elseif (isset($erro)): ?>
        <div class="notification error"><?php echo $erro; ?></div>
    <?php endif; ?>

    <!-- Exibir dados do usuário -->
    <table>
        <tr>
            <th>Nome</th>
            <td><?php echo htmlspecialchars($usuario_nome); ?></td>
        </tr>
        <tr>
            <th>Email</th>
            <td><?php echo htmlspecialchars($usuario_email); ?></td>
        </tr>
    </table>

    <!-- Formulário para alterar a senha -->
    <h2>Alterar Senha</h2>
    <form method="POST">
        <label for="nova_senha">Nova Senha:</label>
        <input type="password" name="nova_senha" id="nova_senha" required>

        <label for="confirmar_senha">Confirmar Senha:</label>
        <input type="password" name="confirmar_senha" id="confirmar_senha" required>

        <button type="submit">Alterar Senha</button>
    </form>

    <a href="home.php">Voltar para a Home</a>
</div>

</body>
</html>
