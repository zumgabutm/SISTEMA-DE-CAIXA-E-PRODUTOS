<?php
include 'conexao.php'; // Conexão com o banco de dados
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

// Consultar as promoções ativas
$query = "
    SELECT p.nome AS produto, pr.desconto, pr.data_inicio, pr.data_fim, p.preco
    FROM promocoes pr
    JOIN produtos p ON pr.produto_id = p.id
    WHERE pr.data_fim >= NOW()
    ORDER BY pr.data_inicio DESC
";
$stmt = $conn->prepare($query);
$stmt->execute();
$promocoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Promoções</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #2a2a2a;
            color: #fff;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #6a1b9a;
        }
        .container {
            max-width: 900px;
            margin: auto;
            background-color: #333;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #444;
            text-align: left;
        }
        th {
            background-color: #6a1b9a;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #444;
        }
        .preco-original {
            text-decoration: line-through;
            color: #ff0000;
        }
        .preco-promocional {
            color: #4caf50;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Promoções Ativas</h1>

        <table>
            <tr>
                <th>Produto</th>
                <th>Desconto (%)</th>
                <th>Preço Original</th>
                <th>Preço Promocional</th>
                <th>Período</th>
            </tr>
            <?php if (count($promocoes) > 0): ?>
                <?php foreach ($promocoes as $promocao): ?>
                <?php
                    // Calcular o preço promocional
                    $preco_promocional = $promocao['preco'] * (1 - ($promocao['desconto'] / 100));
                ?>
                <tr>
                    <td><?php echo htmlspecialchars($promocao['produto']); ?></td>
                    <td><?php echo number_format($promocao['desconto'], 2, ',', '.'); ?>%</td>
                    <td class="preco-original">R$ <?php echo number_format($promocao['preco'], 2, ',', '.'); ?></td>
                    <td class="preco-promocional">R$ <?php echo number_format($preco_promocional, 2, ',', '.'); ?></td>
                    <td><?php echo date('d/m/Y', strtotime($promocao['data_inicio'])) . ' - ' . date('d/m/Y', strtotime($promocao['data_fim'])); ?></td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5">Nenhuma promoção disponível no momento.</td>
                </tr>
            <?php endif; ?>
        </table>
    </div>

</body>
</html>
