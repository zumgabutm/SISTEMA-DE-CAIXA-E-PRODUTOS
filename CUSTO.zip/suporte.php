<?php
include 'conexao.php'; // Inclua o arquivo de conexão com o banco de dados
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

// Obter o ID do usuário logado
$usuario_id = $_SESSION['usuario_id'];

// Enviar ticket de suporte
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['assunto'], $_POST['mensagem'])) {
    $assunto = $_POST['assunto'];
    $mensagem = $_POST['mensagem'];

    // Inserir o ticket de suporte no banco de dados
    $stmt = $conn->prepare("INSERT INTO suporte (usuario_id, assunto, mensagem) VALUES (?, ?, ?)");
    $stmt->execute([$usuario_id, $assunto, $mensagem]);

    $_SESSION['sucesso'] = "Sua solicitação foi enviada com sucesso!";
    header('Location: suporte.php');
    exit;
}

// Buscar os tickets de suporte do usuário
$query = "SELECT assunto, mensagem, status, data_envio FROM suporte WHERE usuario_id = ? ORDER BY data_envio DESC";
$stmt = $conn->prepare($query);
$stmt->execute([$usuario_id]);
$suportes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Suporte</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #2a2a2a;
            color: #fff;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #6a1b9a;
        }
        .container {
            max-width: 900px;
            margin: auto;
            background-color: #333;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }
        form {
            margin-bottom: 30px;
        }
        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }
        input, textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
            border: 1px solid #444;
            background-color: #222;
            color: white;
        }
        button {
            background-color: #6a1b9a;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #9c27b0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #444;
            text-align: left;
        }
        th {
            background-color: #6a1b9a;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #444;
        }
        .status {
            font-weight: bold;
        }
        .status-pendente {
            color: orange;
        }
        .status-andamento {
            color: blue;
        }
        .status-resolvido {
            color: green;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Solicitação de Suporte</h1>

        <!-- Formulário de envio de ticket de suporte -->
        <form method="POST" action="suporte.php">
            <label for="assunto">Assunto:</label>
            <input type="text" id="assunto" name="assunto" required>

            <label for="mensagem">Mensagem:</label>
            <textarea id="mensagem" name="mensagem" rows="5" required></textarea>

            <button type="submit">Enviar Solicitação</button>
        </form>

        <!-- Exibição de mensagens de sucesso -->
        <?php if (isset($_SESSION['sucesso'])): ?>
            <div class="notification success">
                <p><?php echo $_SESSION['sucesso']; ?></p>
            </div>
            <?php unset($_SESSION['sucesso']); ?>
        <?php endif; ?>

        <!-- Histórico de Tickets -->
        <h2>Histórico de Suporte</h2>
        <table>
            <tr>
                <th>Assunto</th>
                <th>Mensagem</th>
                <th>Status</th>
                <th>Data de Envio</th>
            </tr>
            <?php if (count($suportes) > 0): ?>
                <?php foreach ($suportes as $suporte): ?>
                <tr>
                    <td><?php echo htmlspecialchars($suporte['assunto']); ?></td>
                    <td><?php echo htmlspecialchars($suporte['mensagem']); ?></td>
                    <td class="status <?php echo strtolower($suporte['status']); ?>">
                        <?php echo $suporte['status']; ?>
                    </td>
                    <td><?php echo date('d/m/Y H:i:s', strtotime($suporte['data_envio'])); ?></td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4">Nenhum ticket de suporte encontrado.</td>
                </tr>
            <?php endif; ?>
        </table>
    </div>

</body>
</html>
