<?php
include 'conexao.php';
session_start();

if (!isset($_SESSION['loggedin'])) {
    header('Location: index.php');
    exit;
}

// Obter o ID do usuário logado
$usuario_id = $_SESSION['usuario_id'];

// Buscar retiradas do usuário logado
$query_ret = "
    SELECT r.id, p.nome AS nome_produto, r.quantidade, r.data_retirada
    FROM retiradas r
    JOIN produtos p ON r.produto_id = p.id
    WHERE r.usuario_id = ?
    ORDER BY r.data_retirada DESC
";
$stmt_ret = $conn->prepare($query_ret);
$stmt_ret->execute([$usuario_id]);
$retiradas = $stmt_ret->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visualizar Minhas Vendas e Devoluções</title>
    <style>
        /* Resetando margens e padding para consistência */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #1a1a1a;
            color: #fff;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: #2c2c2c;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }

        h1 {
            color: #5a2d91;
            text-align: center;
            margin-bottom: 30px;
        }

        h2 {
            color: #d81b60;
            margin-bottom: 20px;
            font-size: 1.5rem;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #444;
        }

        th {
            background-color: #5a2d91;
            color: white;
        }

        td {
            background-color: #3c3c3c;
        }

        tr:nth-child(even) td {
            background-color: #2a2a2a;
        }

        tr:hover td {
            background-color: #4e1b6d;
            transition: background-color 0.3s;
        }

        td a {
            color: #fff;
            text-decoration: none;
            background-color: #6a1b9a;
            padding: 5px 10px;
            border-radius: 5px;
            text-align: center;
            display: inline-block;
            transition: background-color 0.3s;
        }

        td a:hover {
            background-color: #4e1b6d;
        }

        .button-back {
            display: inline-block;
            margin-top: 30px;
            background-color: #6a1b9a;
            color: white;
            padding: 12px 18px;
            border-radius: 8px;
            text-decoration: none;
            text-align: center;
            font-size: 1.1rem;
            transition: background-color 0.3s;
            width: 100%;
        }

        .button-back:hover {
            background-color: #4e1b6d;
        }

        /* Responsividade */
        @media (max-width: 768px) {
            .container {
                padding: 20px;
            }

            table {
                font-size: 0.9rem;
            }

            .button-back {
                font-size: 1rem;
            }
        }

        @media (max-width: 480px) {
            h1 {
                font-size: 1.5rem;
            }

            table {
                font-size: 0.8rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Minhas Retiradas</h1>

        <!-- Histórico de Retiradas -->
        <h2>Histórico de Retiradas</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Produto</th>
                    <th>Quantidade</th>
                    <th>Data da Retirada</th>
                    <th>Ação</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($retiradas) > 0): ?>
                    <?php foreach ($retiradas as $retirada): ?>
                    <tr>
                        <td><?php echo $retirada['id']; ?></td>
                        <td><?php echo htmlspecialchars($retirada['nome_produto']); ?></td>
                        <td><?php echo $retirada['quantidade']; ?></td>
                        <td><?php echo date('d/m/Y H:i:s', strtotime($retirada['data_retirada'])); ?></td>
                        <td><a href="detalhes_retirada.php?id=<?php echo $retirada['id']; ?>">Detalhes</a></td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5">Nenhuma retirada encontrada.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- Link para voltar -->
        <a href="home.php" class="button-back">Voltar para a Home</a>
    </div>
</body>
</html>
